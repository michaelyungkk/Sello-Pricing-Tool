
import React, { useState, useMemo } from 'react';
import { Product, PricingRules, PromotionEvent, PriceLog, RefundLog } from '../../types';

import { List, Ship, RotateCcw, DollarSign, Activity, Calendar, Columns, Layers } from 'lucide-react';

import { MasterCatalogueTab } from './tabs/MasterCatalogueTab';
import { ShipmentsTab } from './tabs/ShipmentsTab';
import { ReturnsAndRefundsTab } from './tabs/ReturnsAndRefundsTab';
import { PriceMatrixTab } from './tabs/PriceMatrixTab';
import { ProductPerformanceTrendTab } from './tabs/ProductPerformanceTrendTab';
import { PlatformComparisonTab } from './tabs/PlatformComparisonTab';
import { FamilyGroupsTab } from './tabs/FamilyGroupsTab';
import { TabSwitcher } from '../common/TabSwitcher';
import { AliasDrawer } from './parts/AliasDrawer';
import { TagsDrawer } from './parts/TagsDrawer';
import { buildWindow } from '../../services/dateWindow';
import { getTodayKeyMelbourne } from '../../services/dateUtils';
import { ContextBar } from '../common/ContextBar';
import { SkuFamily } from '../../types';

interface ProductManagementPageContainerProps {
    products: Product[];
    pricingRules: PricingRules;
    promotions?: PromotionEvent[];
    priceHistoryMap?: Map<string, PriceLog[]>;
    refundHistory?: RefundLog[];

    dateLabels: { current: string, last: string };
    onUpdateProduct?: (product: Product) => void;
    onViewElasticity?: (product: Product) => void;
    onDeepDive: (sku: string) => void;
    themeColor: string;
    deductRefunds: boolean;
    setDeductRefunds: (v: boolean) => void;
    onAnalyzeCarrier: (carrier: string) => void;
    skuFamilies: SkuFamily[];
    setSkuFamilies: (families: SkuFamily[]) => void;
    pendingFamilySuggestions: SkuFamily[];
    setPendingFamilySuggestions: (suggestions: SkuFamily[]) => void;
}

type Tab = 'catalog' | 'performance' | 'pricing' | 'shipments' | 'returns' | 'comparison' | 'family-groups';

export const ProductManagementPageContainer: React.FC<ProductManagementPageContainerProps> = ({
    products,
    pricingRules,
    priceHistoryMap = new Map(),
    refundHistory = [],

    dateLabels,
    onUpdateProduct,
    onViewElasticity,
    onDeepDive,
    themeColor,
    deductRefunds,
    setDeductRefunds,
    onAnalyzeCarrier,
    skuFamilies,
    setSkuFamilies,
    pendingFamilySuggestions,
    setPendingFamilySuggestions,
    promotions = []
}) => {
    const [activeTab, setActiveTab] = useState<Tab>('performance');
    const [selectedProductForDrawer, setSelectedProductForDrawer] = useState<Product | null>(null);
    const [productForTags, setProductForTags] = useState<Product | null>(null);
    const [shipmentSearchTags, setShipmentSearchTags] = useState<string[]>([]);

    // Time Window State (Mirroring Platform Management)
    const [timeWindow, setTimeWindow] = useState<'7D' | '14D' | '30D' | '60D' | 'ALL' | 'CUSTOM'>('30D');
    const [customStart, setCustomStart] = useState<string>(getTodayKeyMelbourne());
    const [customEnd, setCustomEnd] = useState<string>(getTodayKeyMelbourne());


    const handleViewShipments = (sku: string) => {
        setShipmentSearchTags([sku]);
        setActiveTab('shipments');
    };

    // Family Group Handlers
    const handleConfirmSuggestion = (suggestion: SkuFamily) => {
        const newFamily: SkuFamily = {
            ...suggestion,
            id: `family-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        setSkuFamilies([...skuFamilies, newFamily]);
        setPendingFamilySuggestions(pendingFamilySuggestions.filter(s => s.id !== suggestion.id));
    };

    const handleDismissSuggestion = (id: string) => {
        setPendingFamilySuggestions(pendingFamilySuggestions.filter(s => s.id !== id));
    };

    const handleConfirmAllSuggestions = () => {
        const newFamilies = pendingFamilySuggestions.map(s => ({
            ...s,
            id: `family-${Date.now()}-${Math.random().toString(36).substr(2, 5)}-${s.name}`,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        }));
        setSkuFamilies([...skuFamilies, ...newFamilies]);
        setPendingFamilySuggestions([]);
    };

    const handleAddFamily = (family: SkuFamily) => {
        setSkuFamilies([...skuFamilies, family]);
    };

    const handleEditFamily = (updatedFamily: SkuFamily) => {
        setSkuFamilies(skuFamilies.map(f => f.id === updatedFamily.id ? updatedFamily : f));
    };

    const handleRemoveFamily = (id: string) => {
        setSkuFamilies(skuFamilies.filter(f => f.id !== id));
    };

    const dateWindow = useMemo(() => {
        let mode: 'days' | 'custom' | 'all' = 'days';
        let days = 30;
        if (timeWindow === 'ALL') mode = 'all';
        else if (timeWindow === 'CUSTOM') mode = 'custom';
        else days = parseInt(timeWindow.replace('D', ''));

        return buildWindow({
            mode,
            days,
            startKey: customStart,
            endKey: customEnd,
            excludeToday: true
        });
    }, [timeWindow, customStart, customEnd]);

    const periodLabel = useMemo(() => {
        const start = new Date(dateWindow.startKey);
        const end = new Date(dateWindow.endKey);
        const format = (d: Date, withYear: boolean) => d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: withYear ? 'numeric' : undefined, timeZone: 'UTC' });
        const sameYear = start.getUTCFullYear() === end.getUTCFullYear();
        return `${format(start, !sameYear)} – ${format(end, true)}`;
    }, [dateWindow]);

    return (
        <div className="max-w-full mx-auto space-y-6 pb-10 h-full flex flex-col">
            {/* Top Bar matching Marketplace View */}
            <div className="flex flex-wrap gap-4 items-center justify-between">
                <TabSwitcher
                    tabs={[
                        { key: 'performance', label: 'Performance Trend', icon: Activity },
                        { key: 'catalog', label: 'Master Catalogue', icon: List },
                        { key: 'shipments', label: 'Shipments', icon: Ship },
                        { key: 'returns', label: 'Returns Management', icon: RotateCcw },
                        { key: 'pricing', label: 'Price Matrix', icon: DollarSign },
                        { key: 'comparison', label: 'Platform Comparison', icon: Columns },
                        { key: 'family-groups', label: 'Family Groups', icon: Layers },
                    ]}
                    activeTab={activeTab}
                    onChange={(key) => setActiveTab(key as Tab)}
                    size="sm"
                />

            </div>

            {/* Global Context Control — only relevant for data-driven tabs */}
            {(activeTab === 'performance' || activeTab === 'comparison') && <ContextBar
                timeOptions={[
                    { key: '7D', label: '7D' },
                    { key: '14D', label: '14D' },
                    { key: '30D', label: '30D' },
                    { key: '60D', label: '60D' },
                    { key: 'ALL', label: 'All Time' },
                    { key: 'CUSTOM', label: 'Custom' }
                ]}
                activeWindow={timeWindow}
                onWindowChange={(key) => setTimeWindow(key as any)}
                periodLabel={periodLabel}
                customStart={customStart}
                customEnd={customEnd}
                onCustomStartChange={setCustomStart}
                onCustomEndChange={setCustomEnd}
            >
                <label className="flex items-center gap-2 px-3 py-2 bg-white rounded-lg border border-gray-200 shadow-sm cursor-pointer hover:border-indigo-300 transition-colors">
                    <input type="checkbox" checked={deductRefunds} onChange={e => setDeductRefunds(e.target.checked)} className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500 border-gray-300" />
                    <div className="flex items-center gap-1.5">
                        <RotateCcw className={`w-3.5 h-3.5 ${deductRefunds ? 'text-red-500' : 'text-gray-400'}`} />
                        <span className={`text-[10px] font-bold uppercase tracking-tight ${deductRefunds ? 'text-gray-900' : 'text-gray-500'}`}>Deduct Returns</span>
                    </div>
                </label>
            </ContextBar>}

            <div className="flex-1 min-h-0 relative">
                {activeTab === 'performance' && (
                    <ProductPerformanceTrendTab
                        products={products}
                        priceHistoryMap={priceHistoryMap}
                        refundHistory={refundHistory}
                        dateWindow={{ startKey: dateWindow.startKey, endKey: dateWindow.endKey }}
                        deductRefunds={deductRefunds}
                        themeColor={themeColor}
                        onDeepDive={onDeepDive}
                    />
                )}

                {activeTab === 'catalog' && (
                    <MasterCatalogueTab
                        products={products}
                        skuFamilies={skuFamilies}
                        onEditAliases={setSelectedProductForDrawer}
                        onEditTags={setProductForTags}
                        onViewShipments={handleViewShipments}
                        onViewElasticity={onViewElasticity}
                        onDeepDive={onDeepDive}
                        dateLabels={dateLabels}
                        pricingRules={pricingRules}
                        themeColor={themeColor}
                        priceHistoryMap={priceHistoryMap}
                    />
                )}

                {activeTab === 'returns' && (
                    <ReturnsAndRefundsTab
                        refundHistory={refundHistory}
                        products={products}
                        themeColor={themeColor}
                        pricingRules={pricingRules}
                        onDeepDive={onDeepDive}
                        priceHistoryMap={priceHistoryMap}
                        startDate={dateWindow.startKey}
                        endDate={dateWindow.endKey}
                        onAnalyzeCarrier={onAnalyzeCarrier}
                    />
                )}

                {activeTab === 'shipments' && (
                    <ShipmentsTab
                        products={products}
                        themeColor={themeColor}
                        initialTags={shipmentSearchTags}
                        onTagsChange={setShipmentSearchTags}
                    />
                )}

                {activeTab === 'pricing' && (
                    <PriceMatrixTab
                        products={products}
                        pricingRules={pricingRules}
                        promotions={promotions}
                        themeColor={themeColor}
                    />
                )}

                {activeTab === 'comparison' && (
                    <PlatformComparisonTab
                        products={products}
                        priceHistoryMap={priceHistoryMap}
                        pricingRules={pricingRules}
                        dateWindow={{ startKey: dateWindow.startKey, endKey: dateWindow.endKey }}
                        themeColor={themeColor}
                        deductRefunds={deductRefunds}
                        refundHistory={refundHistory}
                    />
                )}

                {activeTab === 'family-groups' && (
                    <FamilyGroupsTab
                        skuFamilies={skuFamilies}
                        pendingFamilySuggestions={pendingFamilySuggestions}
                        products={products}
                        onConfirmSuggestion={handleConfirmSuggestion}
                        onDismissSuggestion={handleDismissSuggestion}
                        onConfirmAllSuggestions={handleConfirmAllSuggestions}
                        onAddFamily={handleAddFamily}
                        onEditFamily={handleEditFamily}
                        onRemoveFamily={handleRemoveFamily}
                        themeColor={themeColor}
                    />
                )}
            </div>

            {selectedProductForDrawer && (
                <AliasDrawer
                    product={selectedProductForDrawer}
                    pricingRules={pricingRules}
                    onClose={() => setSelectedProductForDrawer(null)}
                    onSave={(updated: Product) => {
                        if (onUpdateProduct) {
                            onUpdateProduct(updated);
                        }
                    }}
                    themeColor={themeColor}
                />
            )}

            {productForTags && (
                <TagsDrawer
                    product={productForTags}
                    products={products}
                    onClose={() => setProductForTags(null)}
                    onSave={(updated: Product) => {
                        if (onUpdateProduct) {
                            onUpdateProduct(updated);
                        }
                    }}
                    themeColor={themeColor}
                />
            )}

        </div>
    );
};
