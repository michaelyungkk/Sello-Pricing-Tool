
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { formatSmartMoney } from '../../../utils/format';
import { createPortal } from 'react-dom';
import { Product, PricingRules, SkuFamily, PriceLog, OptimalPriceResult } from '../../../types';
import { VAT_MULTIPLIER } from '../../../constants';
import { getCanonicalSku } from '../../../services/skuNormalization';
import { FilterBar } from '../../common/FilterBar';
import { GradeBadge } from '../../common/GradeBadge';
import { Search, TrendingUp, TrendingDown, Download, ArrowRight, ChevronDown, Star, X, Layers, Tag, Info, GitMerge, User, Globe, CornerDownLeft, List, Ship, LineChart, Eye, CheckSquare, Square } from 'lucide-react';
import { SortState, sortRows } from '../../../utils/tableSort';
import { SortableHeader } from '../../common/SortableHeader';
import { TablePagination } from '../../common/TablePagination';

interface ProductListProps {
    products: Product[];
    skuFamilies?: SkuFamily[]; // Added
    onEditAliases?: (product: Product) => void;
    onEditTags?: (product: Product) => void;
    onViewShipments?: (sku: string) => void;
    onViewElasticity?: (product: Product, result?: OptimalPriceResult) => void;
    onDeepDive?: (sku: string) => void;
    pricingRules?: PricingRules;
    themeColor: string;
    priceHistoryMap: Map<string, PriceLog[]>;
    optimalPriceResults?: Map<string, OptimalPriceResult>;
}

const DATE_PRESENCE_OPTIONS = ['Has Date', 'Missing Date'];

const formatCatalogueDate = (value?: string) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
};

const matchesDatePresenceFilter = (value: string | undefined, filters: string[]) => {
    if (!filters || filters.length === 0 || filters.length === DATE_PRESENCE_OPTIONS.length) return true;
    const hasValue = Boolean(value);
    const wantsHas = filters.includes('Has Date');
    const wantsMissing = filters.includes('Missing Date');
    return (wantsHas && hasValue) || (wantsMissing && !hasValue);
};

const RecommendationTooltip = ({ product, rect }: { product: Product, rect: DOMRect }) => {
    // Add Scroll Offset to ensure fixed position works correctly on scrolled pages
    const scrollY = window.scrollY;
    const scrollX = window.scrollX;

    const style: React.CSSProperties = {
        position: 'absolute',
        top: `${rect.top + scrollY}px`,
        left: `${rect.left + rect.width / 2 + scrollX}px`,
        transform: 'translate(-50%, -100%) translateY(-8px)',
        zIndex: 9999,
        pointerEvents: 'none'
    };

    return createPortal(
        <div style={style} className="animate-in fade-in zoom-in duration-200">
            <div className="bg-gray-900 text-white p-3 rounded-lg shadow-xl text-xs max-w-xs z-50 border border-gray-700 backdrop-blur-md bg-opacity-95">
                <div className="font-bold mb-2 border-b border-gray-700 pb-1 flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${product.status === 'Critical' ? 'bg-red-500' :
                        product.status === 'Overstock' ? 'bg-orange-500' :
                            product.status === 'Warning' ? 'bg-amber-500' : 'bg-green-500'
                        }`}></span>
                    Inventory Intelligence
                </div>
                <div className="space-y-1.5">
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                        <span className="text-gray-400">Status:</span>
                        <span className={`font-bold text-right ${product.status === 'Critical' ? 'text-red-400' :
                            product.status === 'Overstock' ? 'text-orange-400' :
                                product.status === 'Warning' ? 'text-amber-400' : 'text-green-400'
                            }`}>{product.status}</span>

                        <span className="text-gray-400">Action:</span>
                        <span className="text-right text-gray-200">{product.recommendation}</span>

                        <span className="text-gray-400">Runway:</span>
                        <span className="text-right text-gray-200">{product.daysRemaining > 730 ? '> 2 Years' : `${(product.daysRemaining / 7).toFixed(1)} Weeks`}</span>

                        <span className="text-gray-400">Lead Time:</span>
                        <span className="text-right text-gray-200">{product.leadTimeDays} Days</span>
                    </div>

                    {product.returnRate !== undefined && product.returnRate > 5 && (
                        <div className="mt-2 pt-2 border-t border-gray-700">
                            <div className="flex justify-between items-center text-red-400">
                                <span className="font-bold flex items-center gap-1"><CornerDownLeft className="w-3 h-3" /> High Returns</span>
                                <span>{product.returnRate.toFixed(1)}%</span>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-gray-900"></div>
        </div>,
        document.body
    );
};

interface ProductRowProps {
    product: Product;
    themeColor: string;
    onEditAliases?: (p: Product) => void;
    onEditTags?: (p: Product) => void;
    onViewShipments?: (sku: string) => void;
    onViewElasticity?: (p: Product, result?: OptimalPriceResult) => void;
    onDeepDive?: (sku: string) => void;
    hoveredProduct: { id: string; rect: DOMRect } | null;
    handleMouseEnter: (id: string, e: React.MouseEvent) => void;
    handleMouseLeave: () => void;
    priceHistoryMap: Map<string, PriceLog[]>;
    optimalPriceResults?: Map<string, OptimalPriceResult>;
}

const ProductRow = React.memo(({
    product,
    themeColor,
    onEditAliases,
    onEditTags,
    onViewShipments,
    onViewElasticity,
    onDeepDive,
    handleMouseEnter,
    handleMouseLeave,
    priceHistoryMap,
    optimalPriceResults,
}: ProductRowProps) => {

    const { totalAdSpend, rawAdSpend, adDelta, redistributedRows, hasRedistribution, acos } = useMemo(() => {
        if (!priceHistoryMap || !priceHistoryMap.get) {
            return {
                totalAdSpend: 0,
                rawAdSpend: 0,
                adDelta: 0,
                redistributedRows: 0,
                hasRedistribution: false,
                acos: null
            };
        }
        const logs = priceHistoryMap.get(product.sku) || [];
        const adSpend = logs.reduce((sum, l) => sum + (l.adsSpend || 0), 0);
        const rawSpend = logs.reduce((sum, l) => sum + (l.rawAdsSpend ?? l.adsSpend ?? 0), 0);
        const delta = adSpend - rawSpend;
        const redistributedCount = logs.filter(l =>
            l.rawAdsSpend !== undefined &&
            l.rawAdsSpend !== null &&
            Math.abs((l.adsSpend || 0) - (l.rawAdsSpend || 0)) > 0.0001
        ).length;
        const revenue = logs.reduce((sum, l) =>
            sum + (l.price * (l.velocity || 0) * VAT_MULTIPLIER), 0);
        const acosVal = revenue > 0 ? (adSpend / revenue) * 100 : null;
        return {
            totalAdSpend: adSpend,
            rawAdSpend: rawSpend,
            adDelta: delta,
            redistributedRows: redistributedCount,
            hasRedistribution: redistributedCount > 0,
            acos: acosVal
        };
    }, [product.sku, priceHistoryMap]);
    const [showOptimalReason, setShowOptimalReason] = useState(false);
    const optimalReasonRef = useRef<HTMLDivElement | null>(null);

    useEffect(() => {
        if (!showOptimalReason) return;
        const handleClickOutside = (event: MouseEvent) => {
            if (optimalReasonRef.current && !optimalReasonRef.current.contains(event.target as Node)) {
                setShowOptimalReason(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [showOptimalReason]);

    // Apply 20% VAT Uplift for Display using shared constant
    const currentPriceWithVat = (product.currentPrice || 0) * VAT_MULTIPLIER;
    const oldPriceWithVat = product.oldPrice ? product.oldPrice * VAT_MULTIPLIER : null;

    // Optimal Price Logic (Profit)
    const optimalPriceWithVat = product.optimalPrice ? product.optimalPrice * VAT_MULTIPLIER : null;

    // Max Velocity Price Logic (Volume Fallback)
    const volumePriceWithVat = product.maxVelocityPrice ? product.maxVelocityPrice * VAT_MULTIPLIER : null;

    const runwayWeeks = (product.daysRemaining || 0) / 7;
    const runwayBin = {
        label: runwayWeeks > 104 ? '> 2 Years' : `${runwayWeeks.toFixed(1)} Weeks`,
        color: product.status === 'Critical' ? 'badge-red' :
            product.status === 'Overstock' ? 'badge-orange' :
                product.status === 'Warning' ? 'badge-amber' : 'badge-green'
    };

    const isHighReturns = product.returnRate !== undefined && product.returnRate > 5;

    return (
        <tr key={product.id} className="group text-sm border-b border-gray-100/50 last:border-none">
            <td className="px-4 py-4 text-center w-[80px]">
                <div className="grid grid-cols-2 gap-1.5 w-fit mx-auto">
                    {onDeepDive && (
                        <button
                            onClick={() => onDeepDive(product.sku)}
                            className="text-gray-400 hover:text-theme transition-colors p-1.5 rounded hover:bg-theme-10 border border-transparent hover:border-indigo-100"
                            title="Deep Dive SKU Analysis"
                        >
                            <Search className="w-3.5 h-3.5" />
                        </button>
                    )}
                    {onViewElasticity && (
                        <button
                            onClick={() => onViewElasticity(product, optimalPriceResults?.get(getCanonicalSku(product.sku)))}
                            className="text-gray-400 hover:text-theme transition-colors p-1.5 rounded hover:bg-theme-10 border border-transparent hover:border-indigo-100"
                            title="View Price Curve"
                        >
                            <LineChart className="w-3.5 h-3.5" />
                        </button>
                    )}
                    {onEditTags && (
                        <button
                            onClick={() => onEditTags(product)}
                            className="text-gray-400 hover:text-sky-600 transition-colors p-1.5 rounded hover:bg-sky-50 border border-transparent hover:border-sky-100"
                            title="Edit Seasonal/Event Tags"
                        >
                            <Tag className="w-3.5 h-3.5" />
                        </button>
                    )}
                    {onEditAliases && (
                        <button
                            onClick={() => onEditAliases(product)}
                            className="text-gray-400 hover:text-amber-600 transition-colors p-1.5 rounded hover:bg-amber-50 border border-transparent hover:border-amber-100"
                            title="Edit Aliases / SKU Mapping"
                        >
                            <GitMerge className="w-3.5 h-3.5" />
                        </button>
                    )}
                </div>
            </td>
            <td className="px-4 py-4">
                <div>
                    <div className="flex items-center">
                        <div className="font-bold text-gray-900 font-mono">{product.sku}</div>
                        <GradeBadge gradeLevel={product.gradeLevel} />
                    </div>
                    <div className="text-gray-900 font-medium text-xs mt-1 truncate max-w-[240px] xl:max-w-[350px]" title={product.name}>{product.name}</div>
                    <div className="flex gap-2 mt-1.5">
                        {product.subcategory && (
                            <span className="text-[10px] bg-gray-100 text-gray-600 px-2 py-0.5 rounded border border-gray-200">{product.subcategory}</span>
                        )}
                    </div>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                        {product.seasonTags?.slice(0, 2).map(tag => (
                            <span key={tag} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">{tag}</span>
                        ))}
                        {(product.seasonTags?.length || 0) > 2 && (
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">+{(product.seasonTags?.length || 0) - 2}</span>
                        )}
                        {product.festivalTags?.slice(0, 2).map(tag => (
                            <span key={tag} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">{tag}</span>
                        ))}
                        {(product.festivalTags?.length || 0) > 2 && (
                            <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">+{(product.festivalTags?.length || 0) - 2}</span>
                        )}
                    </div>
                </div>
            </td>
            <td className="px-4 py-4 text-right">
                {(() => {
                    const result = optimalPriceResults?.get(getCanonicalSku(product.sku));
                    if (!result) {
                        // Fallback to old optimalPrice if no new result yet
                        return optimalPriceWithVat ? (
                            <div className="flex items-center justify-end gap-1 font-bold text-gray-400" title="Legacy optimal reference (recalculate benchmarks to update)">
                                <Star className="w-3 h-3" style={{ fill: 'rgba(156,163,175,0.2)' }} />
                                {formatSmartMoney(optimalPriceWithVat)}
                            </div>
                        ) : (
                            <span className="text-gray-300">-</span>
                        );
                    }
                    const isStale = Date.now() - new Date(result.calculatedAt).getTime() > 30 * 24 * 60 * 60 * 1000;
                    const delta = result.recommendedPrice - result.currentPrice;
                    const confidenceBadge = (() => {
                        if (result.source === 'COHORT' || result.confidence < 0.3)
                            return <span className="px-1 py-0.5 text-[8px] font-bold rounded border border-gray-200 text-gray-400">Bench</span>;
                        if (result.confidence >= 0.9)
                            return <span className="px-1 py-0.5 text-[8px] font-bold rounded bg-emerald-100 text-emerald-700">High</span>;
                        if (result.confidence >= 0.5)
                            return <span className="px-1 py-0.5 text-[8px] font-bold rounded bg-amber-100 text-amber-700">Med</span>;
                        return <span className="px-1 py-0.5 text-[8px] font-bold rounded bg-gray-100 text-gray-500">Low</span>;
                    })();
                    return (
                        <div ref={optimalReasonRef} className="relative flex flex-col items-end gap-0.5">
                            <div className="flex items-center gap-1">
                                <span className="font-bold text-gray-900" style={{ fontSize: 13 }}>
                                    {formatSmartMoney(result.recommendedPrice)}
                                </span>
                                {isStale && <span title={`Last calculated ${new Date(result.calculatedAt).toLocaleDateString()}`} className="text-gray-400 text-[10px]">🕐</span>}
                                {confidenceBadge}
                                {showOptimalReason && (
                                    <div className="absolute top-full right-0 mt-2 w-72 p-3 bg-gray-900 text-white text-[11px] rounded-xl shadow-2xl z-[80] normal-case tracking-normal">
                                        <p className="leading-relaxed">{result.reasoning.split('. ').slice(0, 2).join('. ')}.</p>
                                        <div className="mt-1.5 text-gray-400 text-[10px]">
                                            Last calculated: {new Date(result.calculatedAt).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                                        </div>
                                        <div className="absolute bottom-full right-5 -mb-1 border-4 border-transparent border-b-gray-900"></div>
                                    </div>
                                )}
                            </div>
                            <div className="flex items-center justify-end gap-1">
                                {Math.abs(delta) >= 0.01 ? (
                                    <span className={`text-[10px] font-bold ${delta > 0 ? 'text-emerald-600' : 'text-red-500'}`}>
                                        {delta > 0 ? '+' : ''}{formatSmartMoney(delta)}
                                    </span>
                                ) : (
                                    <span className="text-[10px] text-transparent">.</span>
                                )}
                                <button
                                    type="button"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        setShowOptimalReason(prev => !prev);
                                    }}
                                    className="inline-flex items-center justify-center w-4 h-4 rounded-full border border-gray-300 text-[10px] font-bold text-gray-600 bg-white hover:bg-gray-50"
                                    title="Show optimal price summary"
                                    aria-label="Show optimal price summary"
                                >
                                    ?
                                </button>
                            </div>
                        </div>
                    );
                })()}
            </td>
            <td className="px-4 py-4 text-right">
                <div className="text-gray-400 font-medium">
                    {oldPriceWithVat ? formatSmartMoney(oldPriceWithVat) : '-'}
                </div>
            </td>
            <td className="px-4 py-4 text-right">
                <div className="font-bold text-gray-900">{formatSmartMoney(currentPriceWithVat)}</div>
            </td>
            <td className="px-4 py-4 text-right">
                {product.caPrice ? (
                    <div className="font-bold text-purple-600 font-mono" title="Channel Advisor Reference Price">
                        {formatSmartMoney(product.caPrice)}
                    </div>
                ) : (
                    <span className="text-gray-300">—</span>
                )}
            </td>

            <td className="px-4 py-4 text-right">
                <div className="flex flex-col items-end gap-0.5">
                    <span className="font-bold text-gray-900">{product.stockLevel}</span>
                    {product.incomingStock && product.incomingStock > 0 ? (
                        <button
                            onClick={(e) => {
                                e.stopPropagation();
                                if (onViewShipments) onViewShipments(product.sku);
                            }}
                            className="text-[10px] font-semibold text-theme bg-theme-10 px-1.5 py-0.5 rounded border border-indigo-100 flex items-center gap-1 hover:bg-theme-10 hover:border-theme-20 transition-colors cursor-pointer"
                            title="Click to view incoming shipments"
                        >
                            <Ship className="w-3 h-3" />
                            +{product.incomingStock}
                        </button>
                    ) : null}
                </div>
            </td>

            <td
                className="px-4 py-4 text-right cursor-help"
                onMouseEnter={(e) => handleMouseEnter(product.id, e)}
                onMouseLeave={handleMouseLeave}
            >
                <div className="flex flex-col items-end gap-1.5">
                    <span className={`sello-badge ${runwayBin.color}`}>
                        {runwayBin.label}
                    </span>
                    <div className="flex items-center gap-1">
                        {!!product._trendData?.velocityChange && product._trendData.velocityChange < -0.2 && <TrendingDown className="w-3 h-3 text-red-400" />}
                        {!!product._trendData?.velocityChange && product._trendData.velocityChange > 0.2 && <TrendingUp className="w-3 h-3 text-green-400" />}
                        <span className="text-xs font-semibold text-gray-700">
                            {(product.averageDailySales || 0).toFixed(1)} / day
                        </span>
                    </div>
                </div>
            </td>
            <td className="px-4 py-4 text-right">
                <div className="text-gray-700 font-medium whitespace-nowrap">{formatCatalogueDate(product.landedAt)}</div>
            </td>
            <td className="px-4 py-4 text-right">
                <div className="text-gray-700 font-medium whitespace-nowrap">{formatCatalogueDate(product.listingReadyAt)}</div>
            </td>
            <td className="px-4 py-4 text-right">
                {product.returnRate !== undefined ? (
                    <div className={`flex items-center justify-end gap-1 font-medium ${isHighReturns ? 'text-red-600 font-bold' : 'text-gray-500'}`}>
                        {isHighReturns && <CornerDownLeft className="w-3 h-3" />}
                        {product.returnRate.toFixed(1)}%
                    </div>
                ) : <span className="text-gray-300">-</span>}
            </td>
            <td className="px-4 py-4 text-right">
                <div
                    className="flex flex-col items-end"
                    title={hasRedistribution
                        ? `Raw ${formatSmartMoney(rawAdSpend)} | Adjusted ${formatSmartMoney(totalAdSpend)} | Delta ${adDelta > 0 ? '+' : ''}${formatSmartMoney(adDelta)} | ${redistributedRows} redistributed row${redistributedRows === 1 ? '' : 's'}`
                        : 'No ad redistribution on this SKU'}
                >
                    <div className="flex items-center justify-end gap-1">
                        <span
                            className={`font-bold ${hasRedistribution ? (adDelta >= 0 ? 'text-blue-600' : 'text-violet-700') : 'text-gray-900'}`}
                            style={{ color: hasRedistribution ? (adDelta >= 0 ? '#2563eb' : '#5B21B6') : '#111827' }}
                        >
                            {formatSmartMoney(totalAdSpend)}
                        </span>
                        {hasRedistribution && (
                            <span
                                className="inline-flex items-center justify-center w-4 h-4 rounded-full text-[9px] font-bold bg-blue-100 text-blue-700"
                                aria-label="Redistributed ads"
                            >
                                R
                            </span>
                        )}
                    </div>
                    {totalAdSpend > 0 ? (
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full font-bold mt-1 ${acos === null ? 'text-gray-400 italic' :
                            acos < 15 ? 'text-green-600 bg-green-50' :
                                acos <= 30 ? 'text-amber-600 bg-amber-50' : 'text-red-600 bg-red-50'
                            }`}>
                            {acos !== null ? `${acos.toFixed(1)}%` : 'No revenue'}
                        </span>
                    ) : (
                        <span className="text-[10px] text-gray-400 italic">No spend</span>
                    )}
                </div>
            </td>
        </tr>
    );
});
ProductRow.displayName = 'ProductRow';

const FilterDropdown = ({ label, icon: Icon, value, onChange, options, themeColor }: any) => (
    <div
        className="flex items-center border border-gray-300 rounded-lg bg-white overflow-hidden transition-shadow focus-within:ring-2 focus-within:ring-opacity-50"
        style={{ '--tw-ring-color': themeColor } as React.CSSProperties}
    >
        <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 border-r border-gray-200 min-w-fit">
            {Icon && <Icon className="w-3.5 h-3.5 text-gray-400" />}
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">{label}</span>
        </div>
        <div className="relative flex-1 min-w-[120px]">
            <select
                value={value}
                onChange={onChange}
                className="w-full px-3 py-2 bg-transparent text-sm text-gray-900 border-none focus:ring-0 cursor-pointer appearance-none pr-8 truncate"
            >
                <option value="All">All</option>
                {options && options.map((opt: string) => (
                    <option key={opt} value={opt}>{opt}</option>
                ))}
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
        </div>
    </div>
);

const MultiSelectDropdown = ({ label, icon: Icon, selected, onChange, options, themeColor }: any) => {
    const [isOpen, setIsOpen] = useState(false);
    const [dropdownPos, setDropdownPos] = useState({ top: 0, left: 0 });
    const dropdownRef = useRef<HTMLDivElement>(null);
    const triggerRef = useRef<HTMLDivElement>(null);
    const currentSelected = selected || [];

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)
                && triggerRef.current && !triggerRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const toggleOption = (option: string) => {
        if (currentSelected.includes(option)) {
            onChange(currentSelected.filter((item: string) => item !== option));
        } else {
            onChange([...currentSelected, option]);
        }
    };

    const displayText = currentSelected.length === 0 ? 'All' : currentSelected.length === 1 ? currentSelected[0] : `${currentSelected.length} Selected`;

    const handleOpen = () => {
        if (!isOpen && triggerRef.current) {
            const rect = triggerRef.current.getBoundingClientRect();
            setDropdownPos({ top: rect.bottom + window.scrollY + 4, left: rect.left + window.scrollX });
        }
        setIsOpen(!isOpen);
    };

    return (
        <div className="relative">
            <div ref={triggerRef}
                className="flex items-center border border-gray-300 rounded-lg bg-white overflow-hidden cursor-pointer"
                onClick={handleOpen}
                style={{ borderColor: isOpen ? themeColor : '#d1d5db' }}
            >
                <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 border-r border-gray-200 min-w-fit">
                    {Icon && <Icon className="w-3.5 h-3.5 text-gray-400" />}
                    <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">{label}</span>
                </div>
                <div className="flex-1 min-w-[120px] px-3 py-2 flex items-center justify-between">
                    <span className="text-sm text-gray-900 truncate max-w-[140px]">{displayText}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
                </div>
            </div>

            {isOpen && createPortal(
                <div ref={dropdownRef} style={{ position: 'fixed', top: dropdownPos.top, left: dropdownPos.left, zIndex: 9999 }}
                    className="w-64 bg-white border border-gray-200 rounded-lg shadow-xl overflow-hidden">
                    <div className="p-2 border-b border-gray-100 flex justify-between">
                        <button
                            className="text-[10px] text-gray-500 hover:text-gray-800"
                            onClick={() => onChange(options)}
                        >Select All</button>
                        <button
                            className="text-[10px] text-gray-500 hover:text-gray-800"
                            onClick={() => onChange([])}
                        >Clear</button>
                    </div>
                    <div className="max-h-60 overflow-y-auto p-1">
                        {options && options.map((opt: string) => {
                            const isSelected = currentSelected.includes(opt);
                            return (
                                <div
                                    key={opt}
                                    className="flex items-center gap-3 px-3 py-2 hover:bg-gray-50 cursor-pointer rounded-md"
                                    onClick={() => toggleOption(opt)}
                                >
                                    {isSelected ? (
                                        <CheckSquare className="w-4 h-4 text-theme flex-shrink-0" style={{ color: themeColor }} />
                                    ) : (
                                        <Square className="w-4 h-4 text-gray-300 flex-shrink-0" />
                                    )}
                                    <span className={`text-sm ${isSelected ? 'font-medium text-gray-900' : 'text-gray-600'}`}>{opt}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>,
                document.body
            )}
        </div>
    );
};

const FamilyGridView = ({
    products,
    skuFamilies,
    themeColor,
    collapsedFamilies,
    setCollapsedFamilies,
    onEditAliases,
    onEditTags,
    onViewShipments,
    onViewElasticity,
    onDeepDive,
    hoveredProduct,
    handleMouseEnter,
    handleMouseLeave,
    priceHistoryMap,
    optimalPriceResults,
}: any) => {
    const familiesWithProducts = useMemo(() => {
        const familyMap = new Map<string, { family: SkuFamily, items: Product[] }>();
        const ungrouped: Product[] = [];

        if (!skuFamilies) return { families: [], ungrouped: products || [] };

        const skuToFamily = new Map<string, SkuFamily>();
        skuFamilies.forEach((f: SkuFamily) => {
            if (!f || !f.memberSkus) return;
            f.memberSkus.forEach((sku: string) => {
                skuToFamily.set(sku, f);
            });
        });

        (products || []).forEach((p: Product) => {
            if (!p) return;
            const family = skuToFamily.get(p.sku);
            if (family) {
                if (!familyMap.has(family.id)) {
                    familyMap.set(family.id, { family, items: [] });
                }
                familyMap.get(family.id)!.items.push(p);
            } else {
                ungrouped.push(p);
            }
        });

        return {
            families: Array.from(familyMap.values()),
            ungrouped
        };
    }, [products, skuFamilies]);

    const toggleFamily = (id: string) => {
        const next = new Set(collapsedFamilies);
        if (next.has(id)) next.delete(id);
        else next.add(id);
        setCollapsedFamilies(next);
    };

    return (
        <tbody>
            {familiesWithProducts.families.map(({ family, items }) => {
                const totalStock = items.reduce((sum, p) => sum + (p.stockLevel || 0), 0);
                const avgVelocity = items.reduce((sum, p) => sum + (p.averageDailySales || 0), 0) / (items.length || 1);
                const lastUpdates = items.map(p => p.lastUpdated).filter(Boolean).map(d => new Date(d!).getTime());
                let updateRange = '-';
                if (lastUpdates.length > 0) {
                    const minUpdate = new Date(Math.min(...lastUpdates)).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
                    const maxUpdate = new Date(Math.max(...lastUpdates)).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
                    updateRange = minUpdate === maxUpdate ? maxUpdate : `${minUpdate} - ${maxUpdate}`;
                }
                const isCollapsed = collapsedFamilies.has(family.id);

                return (
                    <React.Fragment key={family.id}>
                        <tr className="bg-gray-50/80 border-y border-gray-200/50 cursor-pointer group"
                            onClick={() => toggleFamily(family.id)}
                        >
                            <td className="px-4 py-4" colSpan={2}>
                                <div className="flex items-center gap-3">
                                    <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${isCollapsed ? '-rotate-90' : ''}`} />
                                    <div className="flex items-center gap-2">
                                        <Layers className="w-4 h-4 text-theme" />
                                        <span className="font-bold text-gray-900">{family.name}</span>
                                        <span className="text-xs bg-theme-10 text-theme px-2 py-0.5 rounded-full border border-theme-20">{items.length} SKUs</span>
                                    </div>
                                </div>
                            </td>
                            <td colSpan={3} className="px-4 py-3">
                                <div className="flex items-center gap-6 text-xs font-medium text-gray-500">
                                    <div className="flex flex-col">
                                        <span className="text-[10px] uppercase text-gray-400">Total Stock</span>
                                        <span className="font-bold text-gray-700">{totalStock}</span>
                                    </div>
                                    <div className="flex flex-col">
                                        <span className="text-[10px] uppercase text-gray-400">Avg. Velocity</span>
                                        <span className="font-bold text-gray-700">{avgVelocity.toFixed(1)}/day</span>
                                    </div>
                                </div>
                            </td>
                            <td colSpan={7} className="px-4 py-3 text-right">
                                <div className="flex flex-col items-end pr-4">
                                    <span className="text-[10px] uppercase text-gray-400">Last Synced</span>
                                    <span className="font-bold text-gray-700">{updateRange}</span>
                                </div>
                            </td>
                        </tr>
                        {!isCollapsed && items.map(p => (
                            <ProductRow
                                key={p.id}
                                product={p}
                                themeColor={themeColor}
                                onEditAliases={onEditAliases}
                                onEditTags={onEditTags}
                                onViewShipments={onViewShipments}
                                onViewElasticity={onViewElasticity}
                                onDeepDive={onDeepDive}
                                hoveredProduct={hoveredProduct}
                                handleMouseEnter={handleMouseEnter}
                                handleMouseLeave={handleMouseLeave}
                                priceHistoryMap={priceHistoryMap}
                                optimalPriceResults={optimalPriceResults}
                            />
                        ))}
                    </React.Fragment>
                );
            })}

            {familiesWithProducts.ungrouped.length > 0 && (
                <React.Fragment key="ungrouped">
                    <tr className="bg-gray-50 border-y border-gray-200 cursor-pointer"
                        onClick={() => toggleFamily('ungrouped')}
                    >
                        <td className="px-4 py-3" colSpan={12}>
                            <div className="flex items-center gap-3">
                                <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform duration-200 ${collapsedFamilies.has('ungrouped') ? '-rotate-90' : ''}`} />
                                <span className="font-bold text-gray-600 italic">Ungrouped ({familiesWithProducts.ungrouped.length} SKUs)</span>
                            </div>
                        </td>
                    </tr>
                    {!collapsedFamilies.has('ungrouped') && familiesWithProducts.ungrouped.map((p: Product) => (
                        <ProductRow
                            key={p.id}
                            product={p}
                            themeColor={themeColor}
                            onEditAliases={onEditAliases}
                            onEditTags={onEditTags}
                            onViewShipments={onViewShipments}
                            onViewElasticity={onViewElasticity}
                            onDeepDive={onDeepDive}
                            hoveredProduct={hoveredProduct}
                            handleMouseEnter={handleMouseEnter}
                            handleMouseLeave={handleMouseLeave}
                            priceHistoryMap={priceHistoryMap}
                            optimalPriceResults={optimalPriceResults}
                        />
                    ))}
                </React.Fragment>
            )}
        </tbody>
    );
};

const ProductList: React.FC<ProductListProps> = ({ products = [], skuFamilies = [], onEditAliases, onEditTags, onViewShipments, onViewElasticity, onDeepDive, pricingRules, themeColor, priceHistoryMap, optimalPriceResults }) => {
    const [viewMode, setViewMode] = useState<'LIST' | 'FAMILY'>('LIST');
    const [collapsedFamilies, setCollapsedFamilies] = useState<Set<string>>(new Set(['ungrouped']));
    const [searchQuery, setSearchQuery] = useState('');
    const [searchTags, setSearchTags] = useState<string[]>([]);
    const [debouncedSearch, setDebouncedSearch] = useState('');
    const [statusFilters, setStatusFilters] = useState<string[]>([]);
    const [managerFilters, setManagerFilters] = useState<string[]>([]);
    const [platformFilters, setPlatformFilters] = useState<string[]>([]);
    const [landedDateFilters, setLandedDateFilters] = useState<string[]>([]);
    const [listDateFilters, setListDateFilters] = useState<string[]>([]);

    useEffect(() => {
        const timer = setTimeout(() => setDebouncedSearch(searchQuery), 300);
        return () => clearTimeout(timer);
    }, [searchQuery]);

    const [brandFilters, setBrandFilters] = useState<string[]>([]);
    const [mainCatFilters, setMainCatFilters] = useState<string[]>([]);
    const [subCatFilters, setSubCatFilters] = useState<string[]>([]);

    const [showInactive, setShowInactive] = useState(false);
    const [showOOS, setShowOOS] = useState(true);

    const [velocityFilter, setVelocityFilter] = useState<{ min: string, max: string }>({ min: '', max: '' });


    const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);

    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(25);
    const [hoveredProduct, setHoveredProduct] = useState<{ id: string; rect: DOMRect } | null>(null);

    const [sortConfig, setSortConfig] = useState<SortState<string> | null>({ key: 'status', dir: 'desc' });

    const getEffectiveManager = React.useCallback((platform: string, storedManager: string) => {
        if (pricingRules && pricingRules[platform]?.manager && pricingRules[platform].manager !== 'Unassigned') {
            return pricingRules[platform].manager;
        }
        return storedManager || 'Unassigned';
    }, [pricingRules]);

    const uniqueManagers = useMemo(() => {
        const managerSet = new Set<string>();
        (products || []).forEach(p => (p.channels || []).forEach(c => {
            managerSet.add(getEffectiveManager(c.platform, c.manager));
        }));
        if (pricingRules) {
            Object.values(pricingRules).forEach((r: any) => {
                if (r && r.manager && r.manager !== 'Unassigned') managerSet.add(r.manager);
            });
        }
        return Array.from(managerSet).sort();
    }, [products, pricingRules, getEffectiveManager]);

    const uniquePlatforms = useMemo(() => {
        const platformSet = new Set<string>();
        (products || []).forEach(p => (p.channels || []).forEach(c => platformSet.add(c.platform)));
        if (pricingRules) {
            Object.keys(pricingRules).forEach(k => platformSet.add(k));
        }
        return Array.from(platformSet).sort();
    }, [products, pricingRules]);

    const uniqueBrands = useMemo(() => {
        const brands = new Set((products || []).map(p => p.brand).filter(Boolean) as string[]);
        return Array.from(brands).sort();
    }, [products]);

    const uniqueMainCats = useMemo(() => {
        const cats = new Set((products || []).map(p => p.category).filter(Boolean) as string[]);
        return Array.from(cats).sort();
    }, [products]);

    const uniqueSubCats = useMemo(() => {
        let relevantProducts = products || [];
        if (mainCatFilters.length > 0) {
            relevantProducts = (products || []).filter(p => p.category && mainCatFilters.includes(p.category));
        }
        const subs = new Set(relevantProducts.map(p => p.subcategory).filter(Boolean) as string[]);
        return Array.from(subs).sort();
    }, [products, mainCatFilters]);

    const filteredProducts = useMemo(() => {
        const searchQueryLower = (debouncedSearch || '').toLowerCase();
        const filtered = (products || []).filter(p => {
            if (searchTags && searchTags.length > 0) {
                const matchesTag = searchTags.some(tag => {
                    const t = tag.toLowerCase();
                    return (p.sku || '').toLowerCase().includes(t) ||
                        (p.name || '').toLowerCase().includes(t) ||
                        (p.channels || []).some(c => c.skuAlias?.toLowerCase().includes(t));
                });
                if (!matchesTag) return false;
            } else if (searchQueryLower) {
                const skuMatch    = (p.sku || '').toLowerCase().includes(searchQueryLower);
                const nameMatch   = (p.name || '').toLowerCase().includes(searchQueryLower);
                const aliasMatch  = (p.channels || []).some(c =>
                    c.skuAlias?.toLowerCase().includes(searchQueryLower)
                );
                if (!skuMatch && !nameMatch && !aliasMatch) return false;
            }

            if (!showInactive && (p.stockLevel || 0) <= 0 && (p.averageDailySales || 0) === 0) return false;
            if (!showOOS && (p.stockLevel || 0) <= 0) return false;
            if (brandFilters.length > 0 && (!p.brand || !brandFilters.includes(p.brand))) return false;
            if (mainCatFilters.length > 0 && (!p.category || !mainCatFilters.includes(p.category))) return false;
            if (subCatFilters.length > 0 && (!p.subcategory || !subCatFilters.includes(p.subcategory))) return false;
            if (!matchesDatePresenceFilter(p.landedAt, landedDateFilters)) return false;
            if (!matchesDatePresenceFilter(p.listingReadyAt, listDateFilters)) return false;
            return true;
        });

        let aggregatedData = filtered.map(p => {
            const currentPlatformFilters = platformFilters || [];
            const isPlatformFiltered = currentPlatformFilters.length > 0;
            const matchingChannels = (p.channels || []).filter(c => {
                const matchPlatform = !isPlatformFiltered || currentPlatformFilters.includes(c.platform);
                const effectiveManager = getEffectiveManager(c.platform, c.manager);
                const matchManager = managerFilters.length === 0 || managerFilters.includes(effectiveManager);
                return matchPlatform && matchManager;
            });

            const isFiltering = isPlatformFiltered || managerFilters.length > 0;
            let displayVelocity = p.averageDailySales || 0;
            let displayPrice = p.currentPrice || 0;

            if (isFiltering) {
                const totalFilteredVelocity = matchingChannels.reduce((sum, c) => sum + (c.velocity || 0), 0);
                let weightedPriceSum = 0;
                let weightedDivisor = 0;

                matchingChannels.forEach(c => {
                    const price = c.price || p.currentPrice || 0;
                    weightedPriceSum += (price * (c.velocity || 0));
                    weightedDivisor += (c.velocity || 0);
                });

                if (weightedDivisor > 0) {
                    displayPrice = Number((weightedPriceSum / weightedDivisor).toFixed(2));
                } else if (matchingChannels.length > 0) {
                    const sumPrices = matchingChannels.reduce((sum, c) => sum + (c.price || p.currentPrice || 0), 0);
                    displayPrice = Number((sumPrices / matchingChannels.length).toFixed(2));
                }
                displayVelocity = totalFilteredVelocity;
            }

            const stock = p.stockLevel || 0;
            const leadTime = p.leadTimeDays || 30;
            const displayRunway = stock <= 0 ? 0 : (displayVelocity > 0 ? stock / displayVelocity : 999);

            let displayStatus: 'Critical' | 'Warning' | 'Healthy' | 'Overstock' = 'Healthy';
            let displayRec = 'Maintain';

            if (stock <= 0) {
                displayStatus = 'Critical';
                displayRec = 'Out of Stock';
            } else if (displayRunway < leadTime) {
                displayStatus = 'Critical';
                displayRec = 'Increase Price';
            } else if (displayRunway > leadTime * 4) {
                displayStatus = 'Overstock';
                displayRec = 'Decrease Price';
            } else if (displayRunway < leadTime * 1.5) {
                displayStatus = 'Warning';
                displayRec = 'Maintain';
            }

            const shouldShow = !isFiltering || matchingChannels.length > 0;

            return {
                ...p,
                _isVisible: shouldShow,
                averageDailySales: displayVelocity,
                currentPrice: displayPrice,
                daysRemaining: displayRunway,
                status: displayStatus,
                recommendation: displayRec
            };
        }).filter(p => p._isVisible);

        // Apply Velocity Filter
        const minVel = parseFloat(velocityFilter.min);
        const maxVel = parseFloat(velocityFilter.max);
        if (!isNaN(minVel)) {
            aggregatedData = aggregatedData.filter(p => p.averageDailySales >= minVel);
        }
        if (!isNaN(maxVel)) {
            aggregatedData = aggregatedData.filter(p => p.averageDailySales <= maxVel);
        }

        // Apply Status Filter (Context Aware)
        if (statusFilters.length > 0) {
            aggregatedData = aggregatedData.filter(p => statusFilters.includes(p.status));
        }

        const getValue = (row: any, key: string) => {
            if (key === 'status') {
                const priority = { 'Critical': 4, 'Overstock': 3, 'Warning': 2, 'Healthy': 1 };
                return priority[row.status as keyof typeof priority] || 0;
            }
            return (row as any)[key];
        };

        return sortRows(aggregatedData, sortConfig, getValue);

    }, [products, debouncedSearch, searchTags, statusFilters, managerFilters, platformFilters, brandFilters, mainCatFilters, subCatFilters, landedDateFilters, listDateFilters, sortConfig, showInactive, showOOS, velocityFilter, getEffectiveManager]);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchQuery, searchTags, statusFilters, managerFilters, platformFilters, brandFilters, mainCatFilters, subCatFilters, landedDateFilters, listDateFilters, showInactive, showOOS, velocityFilter]);

    useEffect(() => {
        setSubCatFilters([]);
    }, [mainCatFilters]);

    const totalPages = Math.ceil((filteredProducts || []).length / itemsPerPage);
    const paginatedProducts = (filteredProducts || []).slice(
        (currentPage - 1) * itemsPerPage,
        currentPage * itemsPerPage
    );

    const handleMouseEnter = (id: string, event: React.MouseEvent) => {
        const rect = event.currentTarget.getBoundingClientRect();
        setHoveredProduct({ id, rect });
    };

    const handleMouseLeave = () => {
        setHoveredProduct(null);
    };

    const isContextFiltered = (platformFilters && platformFilters.length > 0) || managerFilters.length > 0;

    const handleExport = async (platform: string = 'All') => {
        const XLSX = await import('xlsx-js-style');
        const headers = [
            'SKU',
            'Master SKU',
            'Name',
            'Brand',
            'Category',
            'Subcategory',
            'Grade Level',
            'Optimal Price',
            'Current Price',
            'CA Price',
            'Cost',
            'Stock (units)',
            'Velocity (/day)',
            'Days Remaining',
            'Status',
            'Return Rate',
            'Landed Date',
            'List Date'
        ];

        const rows: any[][] = [headers];

        (filteredProducts || []).forEach(p => {
            const effectiveOptimal = (p.optimalPrice || p.maxVelocityPrice || 0);
            const commonData = [
                p.sku || '',
                p.name || '',
                p.brand || '',
                p.category || '',
                p.subcategory || '',
                p.gradeLevel ?? '',
                effectiveOptimal || '',
                p.currentPrice || 0,
                p.caPrice || '',
                p.costPrice || 0,
                p.stockLevel || 0,
                Number((p.averageDailySales || 0).toFixed(2)),
                Number((p.daysRemaining || 0).toFixed(0)),
                p.status || '',
                (p.returnRate || 0) / 100,
                p.landedAt || '',
                p.listingReadyAt || ''
            ];

            if (platform === 'All') {
                rows.push([p.sku || '', ...commonData]);
            } else {
                const normalize = (s: string) => (s || '').toLowerCase().trim();
                const targetPlatform = normalize(platform);
                let channel = (p.channels || []).find(c => normalize(c.platform) === targetPlatform);
                if (!channel) {
                    channel = (p.channels || []).find(c => normalize(c.platform).includes(targetPlatform) || targetPlatform.includes(normalize(c.platform)));
                }

                if (channel && channel.skuAlias) {
                    const aliases = channel.skuAlias.split(',').map(s => s.trim()).filter(Boolean);
                    if (aliases.length > 0) {
                        aliases.forEach(alias => rows.push([alias, ...commonData]));
                    } else {
                        rows.push([p.sku || '', ...commonData]);
                    }
                } else {
                    rows.push([p.sku || '', ...commonData]);
                }
            }
        });

        const ws = XLSX.utils.aoa_to_sheet(rows);
        const range = XLSX.utils.decode_range(ws['!ref'] || 'A1:A1');

        ws['!cols'] = [
            { wch: 20 }, // SKU
            { wch: 20 }, // Master SKU
            { wch: 40 }, // Name
            { wch: 18 }, // Brand
            { wch: 18 }, // Category
            { wch: 18 }, // Subcategory
            { wch: 12 }, // Grade
            { wch: 14 }, // Optimal
            { wch: 14 }, // Current
            { wch: 14 }, // CA
            { wch: 12 }, // Cost
            { wch: 14 }, // Stock
            { wch: 14 }, // Velocity
            { wch: 14 }, // Days
            { wch: 12 }, // Status
            { wch: 12 }, // Return rate
            { wch: 14 }, // Landed date
            { wch: 14 }, // List date
        ];

        ws['!autofilter'] = { ref: XLSX.utils.encode_range(range) };
        ws['!freeze'] = { xSplit: 0, ySplit: 1 };

        for (let c = range.s.c; c <= range.e.c; c++) {
            const headerAddr = XLSX.utils.encode_cell({ r: 0, c });
            const headerCell = ws[headerAddr];
            if (!headerCell) continue;
            headerCell.s = {
                font: { bold: true, color: { rgb: '1F2937' } },
                fill: { fgColor: { rgb: 'F3F4F6' } },
                alignment: { horizontal: 'center', vertical: 'center' }
            };
        }

        const gbpCols = [7, 8, 9, 10]; // Optimal, Current, CA, Cost
        const intCols = [6, 11, 13]; // Grade, Stock, Days
        const velocityCol = 12;
        const returnRateCol = 15;

        for (let r = 1; r <= range.e.r; r++) {
            for (let c = range.s.c; c <= range.e.c; c++) {
                const addr = XLSX.utils.encode_cell({ r, c });
                const cell = ws[addr];
                if (!cell) continue;

                if (gbpCols.includes(c) && typeof cell.v === 'number') {
                    cell.z = '"£"#,##0.00';
                    cell.t = 'n';
                } else if (intCols.includes(c) && typeof cell.v === 'number') {
                    cell.z = '#,##0';
                    cell.t = 'n';
                } else if (c === velocityCol && typeof cell.v === 'number') {
                    cell.z = '0.00';
                    cell.t = 'n';
                } else if (c === returnRateCol && typeof cell.v === 'number') {
                    cell.z = '0.00%';
                    cell.t = 'n';
                }
            }
        }

        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Master Catalogue');
        const filename = platform === 'All'
            ? 'inventory_export_master.xlsx'
            : `inventory_export_${platform.toLowerCase().replace(/\s+/g, '_')}.xlsx`;
        XLSX.writeFile(wb, filename, { cellStyles: true });
        setIsExportMenuOpen(false);
    };

    const tooltipProduct = hoveredProduct ? (filteredProducts || []).find(p => p.id === hoveredProduct.id) : null;

    return (
        <div className="space-y-4">
            <div className="bg-custom-glass p-4 rounded-xl border border-custom-glass shadow-sm flex flex-col xl:flex-row items-center justify-between gap-4 relative overflow-hidden backdrop-blur-custom">
                <div className="flex items-center justify-between w-full xl:w-auto gap-6">
                    <div className="flex items-center gap-2">
                        <List className="w-5 h-5 text-gray-400" />
                        <span className="text-sm font-bold text-gray-700 whitespace-nowrap">Master Catalogue</span>
                    </div>

                    {skuFamilies.length > 0 && (
                        <div className="flex bg-gray-100/50 p-1 rounded-lg border border-gray-200">
                            <button
                                onClick={() => setViewMode('LIST')}
                                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${viewMode === 'LIST' ? 'bg-white shadow-sm text-theme' : 'text-gray-500 hover:text-gray-700'}`}
                            >
                                <List className="w-3.5 h-3.5" />
                                List View
                            </button>
                            <button
                                onClick={() => setViewMode('FAMILY')}
                                className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center gap-2 ${viewMode === 'FAMILY' ? 'bg-white shadow-sm text-theme' : 'text-gray-500 hover:text-gray-700'}`}
                            >
                                <Layers className="w-3.5 h-3.5" />
                                Family View
                            </button>
                        </div>
                    )}
                </div>

                <div className="w-full xl:w-auto flex justify-end relative">
                    <button
                        onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                        className="sello-btn"
                    >
                        <Download className="w-3.5 h-3.5" />
                        Export List
                        <ChevronDown className="w-3 h-3 text-gray-400" />
                    </button>

                    {isExportMenuOpen && createPortal(
                        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/20 backdrop-blur-sm" onClick={() => setIsExportMenuOpen(false)}>
                            <div
                                className="bg-custom-glass-modal backdrop-blur-custom-modal rounded-xl shadow-2xl w-full max-w-sm overflow-hidden animate-in fade-in zoom-in duration-200 border border-white/20"
                                onClick={e => e.stopPropagation()}
                            >
                                <div className="p-4 border-b border-gray-100/50 flex justify-between items-center bg-gray-50/50">
                                    <h3 className="font-bold text-gray-900">Export Options</h3>
                                    <button onClick={() => setIsExportMenuOpen(false)} className="p-1 hover:bg-gray-200/50 rounded-full transition-colors">
                                        <X className="w-4 h-4 text-gray-500" />
                                    </button>
                                </div>

                                <div className="p-2">
                                    <div className="px-3 py-2 text-xs font-bold text-gray-400 uppercase tracking-wider">Select Format</div>
                                    <button
                                        onClick={() => handleExport('All')}
                                        className="w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-gray-50/50 flex items-center justify-between group rounded-lg transition-colors"
                                    >
                                        <span className="font-medium">Standard (Master SKUs)</span>
                                        <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-gray-600" />
                                    </button>

                                    <div className="my-2 border-t border-gray-100/50"></div>

                                    <div className="px-3 py-2 text-xs font-bold text-gray-400 uppercase tracking-wider">Export for Platform</div>
                                    <div className="max-h-60 overflow-y-auto">
                                        {uniquePlatforms.map(platform => (
                                            <button
                                                key={platform}
                                                onClick={() => handleExport(platform)}
                                                className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50/50 flex items-center justify-between rounded-lg transition-colors"
                                            >
                                                <span>{platform}</span>
                                                <span className="text-[10px] bg-gray-100 text-gray-500 px-2 py-0.5 rounded border border-gray-200">Alias Mode</span>
                                            </button>
                                        ))}
                                        {uniquePlatforms.length === 0 && (
                                            <div className="px-4 py-2 text-xs text-gray-400 italic">No platforms detected</div>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>,
                        document.body
                    )}
                </div>
            </div>
            <div className="bg-custom-glass rounded-xl border border-custom-glass shadow-lg flex flex-col backdrop-blur-custom relative z-20">
                <div className="p-4">
                    <FilterBar
                        searchTags={searchTags}
                        onSearchTagsChange={(tags) => { setSearchTags(tags); setCurrentPage(1); }}
                        onSearchChange={(val) => { setSearchQuery(val); setCurrentPage(1); }}
                        searchPlaceholder="Search or paste SKUs..."
                        multiSelects={[
                            {
                                key: 'brand',
                                label: 'Brand',
                                icon: Tag,
                                options: uniqueBrands,
                                selected: brandFilters,
                                onChange: (selected) => { setBrandFilters(selected); setCurrentPage(1); }
                            },
                            {
                                key: 'category',
                                label: 'Category',
                                icon: Layers,
                                options: uniqueMainCats,
                                selected: mainCatFilters,
                                onChange: (selected) => { setMainCatFilters(selected); setCurrentPage(1); }
                            },
                            {
                                key: 'subcat',
                                label: 'Subcat',
                                icon: GitMerge,
                                options: uniqueSubCats,
                                selected: subCatFilters,
                                onChange: (selected) => { setSubCatFilters(selected); setCurrentPage(1); }
                            },
                            {
                                key: 'status',
                                label: 'Status',
                                options: ['Critical', 'Overstock', 'Healthy', 'Warning'],
                                selected: statusFilters,
                                onChange: (selected) => { setStatusFilters(selected); setCurrentPage(1); }
                            },
                            {
                                key: 'platform',
                                label: 'Platform',
                                icon: Globe,
                                options: uniquePlatforms,
                                selected: platformFilters,
                                onChange: (selected) => { setPlatformFilters(selected); setCurrentPage(1); }
                            },
                            {
                                key: 'manager',
                                label: 'Manager',
                                icon: User,
                                options: uniqueManagers,
                                selected: managerFilters,
                                onChange: (selected) => { setManagerFilters(selected); setCurrentPage(1); }
                            },
                            {
                                key: 'landed-date',
                                label: 'Landed Date',
                                options: DATE_PRESENCE_OPTIONS,
                                selected: landedDateFilters,
                                onChange: (selected) => { setLandedDateFilters(selected); setCurrentPage(1); }
                            },
                            {
                                key: 'list-date',
                                label: 'List Date',
                                options: DATE_PRESENCE_OPTIONS,
                                selected: listDateFilters,
                                onChange: (selected) => { setListDateFilters(selected); setCurrentPage(1); }
                            }
                        ]}
                        toggles={[
                            {
                                key: 'oos',
                                label: 'Show Out Of Stock',
                                active: showOOS,
                                onChange: (active) => setShowOOS(active)
                            },
                            {
                                key: 'inactive',
                                label: 'Show Inactive',
                                active: showInactive,
                                onChange: (active) => setShowInactive(active)
                            }
                        ]}
                        rangeFilters={[
                            {
                                key: 'velocity',
                                label: 'Velocity',
                                minValue: velocityFilter.min,
                                maxValue: velocityFilter.max,
                                onMinChange: (val) => setVelocityFilter(prev => ({ ...prev, min: val })),
                                onMaxChange: (val) => setVelocityFilter(prev => ({ ...prev, max: val })),
                                minPlaceholder: 'Min',
                                maxPlaceholder: 'Max',
                            }
                        ]}
                        rightSlot={
                            <div className="text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">
                                Showing <span className="text-theme">{filteredProducts.length.toLocaleString()}</span> of{' '}
                                <span className="text-gray-700">{products.length.toLocaleString()}</span> SKUs
                            </div>
                        }
                    />
                </div>
            </div>
            {isContextFiltered && (
                <div
                    className="flex items-center gap-2 px-4 py-2 rounded-lg border text-sm animate-in fade-in slide-in-from-top-2 backdrop-blur-sm"
                    style={{ backgroundColor: `${themeColor}10`, borderColor: `${themeColor}30`, color: themeColor }}
                >
                    <Info className="w-4 h-4" />
                    <span>
                        Showing data aggregated for
                        {platformFilters && platformFilters.length > 0 && <strong> {platformFilters.length} Platform(s) </strong>}
                        {platformFilters && platformFilters.length > 0 && managerFilters.length > 0 && <span>and</span>}
                        {managerFilters.length > 0 && <strong> {managerFilters.length} Manager(s) </strong>}
                        only. Prices are recalculated weighted averages for this selection.
                    </span>
                </div>
            )}

            <div className="bg-custom-glass rounded-xl shadow-lg border border-custom-glass overflow-visible backdrop-blur-custom">
                <div className="sello-table-scroll overflow-y-visible">
                    <table className="sello-table">
                        <thead className="sticky top-0">
                            <tr className="bg-gray-50/80 border-b border-gray-200 text-xs uppercase tracking-wider text-gray-500 font-semibold backdrop-blur-sm shadow-sm">
                                <th className="px-4 py-3 font-semibold text-center w-[80px] text-xs uppercase text-gray-600 tracking-wider">Actions</th>
                                <SortableHeader label="Product" sortKey="sku" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} className="min-w-[250px]" />
                                <SortableHeader label="Optimal Price" sortKey="optimalPrice" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[120px]" />
                                <SortableHeader label="Last Week" sortKey="oldPrice" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[110px]" />
                                <SortableHeader label={isContextFiltered ? "Current (Filt.)" : "Current"} sortKey="currentPrice" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[110px]" />
                                <SortableHeader label="CA Price" sortKey="caPrice" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[100px]" />
                                <SortableHeader label="Inventory" sortKey="stockLevel" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[120px]" />
                                <SortableHeader label={isContextFiltered ? "Runway (Filt.)" : "Runway"} sortKey="daysRemaining" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[140px]" />
                                <SortableHeader label="Landed Date" sortKey="landedAt" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[120px]" />
                                <SortableHeader label="List Date" sortKey="listingReadyAt" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[120px]" />
                                <SortableHeader label="Returns" sortKey="returnRate" sort={sortConfig} onChange={setSortConfig} themeColor={themeColor} align="right" className="w-[100px]" />
                                <th className="px-4 py-3 text-right text-[10px] font-bold text-gray-500 uppercase tracking-wider w-[120px]" title="All-time ad spend and ACOS. ACOS = Ad Spend / Revenue × 100. Hover each cell for raw vs adjusted ad details.">
                                    Ad Spend / ACOS
                                </th>
                            </tr>
                        </thead>
                        {viewMode === 'LIST' ? (
                            <tbody>
                                {paginatedProducts.map((product) =>
                                    <ProductRow
                                        key={product.id}
                                        product={product}
                                        themeColor={themeColor}
                                        onEditAliases={onEditAliases}
                                        onEditTags={onEditTags}
                                        onViewShipments={onViewShipments}
                                        onViewElasticity={onViewElasticity}
                                        onDeepDive={onDeepDive}
                                        hoveredProduct={hoveredProduct}
                                        handleMouseEnter={handleMouseEnter}
                                        handleMouseLeave={handleMouseLeave}
                                        priceHistoryMap={priceHistoryMap}
                                        optimalPriceResults={optimalPriceResults}
                                    />
                                )}
                                {(!filteredProducts || filteredProducts.length === 0) && (
                                    <tr>
                                        <td colSpan={12} className="p-8 text-center text-gray-500">
                                            <div className="flex flex-col items-center justify-center gap-2">
                                                <p>No products found matching your filters.</p>
                                                {products && products.length > 0 && !showInactive && (
                                                    <button
                                                        onClick={() => setShowInactive(true)}
                                                        className="text-theme text-sm font-medium hover:underline flex items-center gap-1"
                                                    >
                                                        <Eye className="w-4 h-4" />
                                                        Show {products.length - (filteredProducts?.length || 0)} hidden items (Inactive/Ghost)
                                                    </button>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        ) : (
                            <FamilyGridView
                                products={filteredProducts}
                                skuFamilies={skuFamilies}
                                themeColor={themeColor}
                                collapsedFamilies={collapsedFamilies}
                                setCollapsedFamilies={setCollapsedFamilies}
                                onEditAliases={onEditAliases}
                                onEditTags={onEditTags}
                                onViewShipments={onViewShipments}
                                onViewElasticity={onViewElasticity}
                                onDeepDive={onDeepDive}
                                hoveredProduct={hoveredProduct}
                                handleMouseEnter={handleMouseEnter}
                                handleMouseLeave={handleMouseLeave}
                                priceHistoryMap={priceHistoryMap}
                                optimalPriceResults={optimalPriceResults}
                            />
                        )}
                    </table>
                </div>

                <TablePagination
                    currentPage={currentPage}
                    itemsPerPage={itemsPerPage}
                    totalCount={filteredProducts.length}
                    totalPages={totalPages}
                    setCurrentPage={setCurrentPage}
                    setItemsPerPage={setItemsPerPage}
                />
            </div>

            {tooltipProduct && hoveredProduct && (
                <RecommendationTooltip
                    product={tooltipProduct}
                    rect={hoveredProduct.rect}
                />
            )}
        </div>
    );
};

export default ProductList;

