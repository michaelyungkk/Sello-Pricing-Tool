
import { Product, PriceLog } from '../types';
import { POSTCODE_COORDS } from '../data/ukPostcodeMapCoords';
import { getAreaDemographics } from '../data/ukAreaDemographics';
import { calcRevenue, calcProfit, calcUnits, calcAdSpend, calcMarginPct, calcTACoSPct } from './metrics';
import { asDateKey, isDateKeyBetween, addDaysToDateKey } from './dateUtils';
import { scaleMoneyInclTax, assertNotAlreadyScaled } from './taxPolicy';

// In-component type for aggregated data
export interface DistrictData {
    code: string;
    revenue: number;
    volume: number;
    profit: number;
    totalShippingCost: number;
    avgShippingCost: number;
}
export interface AreaData {
    code: string;
    incomeBand: string;
    householdProfile: string;
    deprivationDecile: number | null;
    ruralUrbanFlag: string;
    revenue: number;
    volume: number;
    orders: number;
    profit: number;
    margin: number;
    returnRate: number;
    avgShippingCost: number;
    totalShippingCost: number;
    adSpend: number;
    tacos: number;
    coordinates: [number, number];
    platformBreakdown: { platform: string; revenue: number; volume: number; profit: number }[];
    topSkus: { sku: string; name: string; profit: number; volume: number; revenue: number }[];
    prevRevenue: number;
    prevVolume: number;
    prevProfit: number;
    revenueDelta: number;
    volumeDelta: number;
    profitDelta: number;
    revenueDeltaPct: number;
    volumeDeltaPct: number;
    profitDeltaPct: number;
    districtBreakdown: DistrictData[];
    // Guardrail: Explicit flag to indicate monetary values are tax-inclusive
    moneyIsTaxInclusive?: boolean;
}

export interface SkuAreaCompareRow {
    areaCode: string;
    units: number;
    orders: number;
    revenue: number;
    profit: number;
    sharePct: number;
    rank: number;
}

export interface SkuAreaComparisonGroup {
    sku: string;
    productName: string;
    totalUnits: number;
    rows: SkuAreaCompareRow[];
}


interface MapFilters {
  startDate: Date;
  endDate: Date;
  selectedPlatform: string;
  selectedCategory: string;
  selectedSubcategory: string;
  selectedCarrier: string;
}

export const aggregateSkuAreaComparisonData = (
  products: Product[],
  priceHistoryMap: Map<string, PriceLog[]>,
  filters: MapFilters,
  selectedSkus: string[],
  topN: number = 10
): SkuAreaComparisonGroup[] => {
    const { startDate, endDate, selectedPlatform, selectedCategory, selectedSubcategory, selectedCarrier } = filters;
    const startKey = asDateKey(startDate);
    const endKey = asDateKey(endDate);
    if (!startKey || !endKey || !Array.isArray(selectedSkus) || selectedSkus.length === 0) return [];

    const productBySku = new Map<string, Product>();
    (products || []).forEach(p => {
        const key = String(p.sku || '').trim().toUpperCase();
        if (key) productBySku.set(key, p);
    });

    return selectedSkus.map(rawSku => {
        const skuKey = String(rawSku || '').trim().toUpperCase();
        const product = productBySku.get(skuKey);
        const logs = priceHistoryMap.get(skuKey) || [];

        const areaStats: Record<string, { units: number; orders: number; revenue: number; profit: number }> = {};

        logs.forEach(log => {
            const dKey = asDateKey(log.date);
            if (!dKey || !isDateKeyBetween(dKey, startKey, endKey)) return;
            if (selectedPlatform !== 'All' && log.platform !== selectedPlatform) return;
            if (selectedCarrier !== 'All') {
                const partner = log.logisticPartner || 'Unknown';
                if (partner !== selectedCarrier) return;
            }
            if (!log.postcode) return;

            const areaMatch = log.postcode.match(/^([A-Z]{1,2})/i);
            if (!areaMatch) return;
            const areaCode = areaMatch[1].toUpperCase();

            const units = calcUnits(log);
            if (!isFinite(units) || units <= 0) return;

            if (selectedCategory !== 'All' || selectedSubcategory !== 'All') {
                if (!product) return;
                if (selectedCategory !== 'All' && product.category !== selectedCategory) return;
                if (selectedSubcategory !== 'All' && product.subcategory !== selectedSubcategory) return;
            }

            if (!areaStats[areaCode]) {
                areaStats[areaCode] = { units: 0, orders: 0, revenue: 0, profit: 0 };
            }
            areaStats[areaCode].units += units;
            areaStats[areaCode].orders += 1;
            areaStats[areaCode].revenue += calcRevenue(log);
            areaStats[areaCode].profit += calcProfit(log);
        });

        const totalUnits = Object.values(areaStats).reduce((sum, v) => sum + v.units, 0);

        const rows = Object.entries(areaStats)
            .map(([areaCode, stats]) => {
                const revenue = scaleMoneyInclTax(stats.revenue);
                const profit = scaleMoneyInclTax(stats.profit);
                return {
                    areaCode,
                    units: stats.units,
                    orders: stats.orders,
                    revenue,
                    profit,
                    sharePct: totalUnits > 0 ? (stats.units / totalUnits) * 100 : 0,
                    rank: 0
                };
            })
            .sort((a, b) => {
                if (b.units !== a.units) return b.units - a.units;
                if (b.orders !== a.orders) return b.orders - a.orders;
                return b.revenue - a.revenue;
            })
            .slice(0, Math.max(1, topN))
            .map((row, index) => ({ ...row, rank: index + 1 }));

        return {
            sku: rawSku,
            productName: product?.name || rawSku,
            totalUnits,
            rows
        };
    });
};

export const aggregateUkMapData = (
  products: Product[],
  priceHistoryMap: Map<string, PriceLog[]>,
  filters: MapFilters
): AreaData[] => {
    const { startDate, endDate, selectedPlatform, selectedCategory, selectedSubcategory, selectedCarrier } = filters;

    const startKey = asDateKey(startDate);
    const endKey = asDateKey(endDate);

    if (!startKey || !endKey) {
        return [];
    }

    const durationMs = new Date(endKey).getTime() - new Date(startKey).getTime();
    const durationDays = Math.round(durationMs / (1000 * 60 * 60 * 24)) + 1;

    const prevEndKey = addDaysToDateKey(startKey, -1);
    const prevStartKey = addDaysToDateKey(prevEndKey, -(durationDays - 1));
    
    const areaStats: Record<string, { 
        revenue: number, 
        volume: number, 
        orders: number,
        profit: number, 
        prevRevenue: number;
        prevVolume: number;
        prevProfit: number;
        returnedUnits: number,
        totalPostage: number,
        totalAdSpend: number,
        platforms: Record<string, { revenue: number, volume: number, profit: number }>,
        skus: Record<string, { name: string; profit: number; volume: number; revenue: number }>
    }> = {};
    
    const districtStats: Record<string, { revenue: number, volume: number, profit: number, totalPostage: number }> = {};

    const skuMap = new Map<string, Product>();
    
    // Pre-filter products to optimize loop
    const relevantProducts = products.filter(p => {
        if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
        if (selectedSubcategory !== 'All' && p.subcategory !== selectedSubcategory) return false;
        return true;
    });

    relevantProducts.forEach(p => skuMap.set(p.sku, p));
    const validSkus = new Set(relevantProducts.map(p => p.sku));

    // Iterate through all history logs
    for (const [sku, logs] of priceHistoryMap.entries()) {
        if (!validSkus.has(sku)) continue;
        const product = skuMap.get(sku);
        if (!product) continue;

        logs.forEach(log => {
            // Apply Global Filters
            if (selectedPlatform !== 'All' && log.platform !== selectedPlatform) return;
            
            // Apply Carrier Filter
            if (selectedCarrier !== 'All') {
                const partner = log.logisticPartner || 'Unknown';
                if (partner !== selectedCarrier) return;
            }
            
            const logKey = asDateKey(log.date);
            if (!logKey) return;
            
            // Extract Postcode Area
            if (!log.postcode) return;
            const areaMatch = log.postcode.match(/^([A-Z]{1,2})/i); 
            const districtMatch = log.postcode.match(/^([A-Z]{1,2}[0-9R][0-9A-Z]?)/i);
            
            if (!areaMatch) return;
            const areaCode = areaMatch[1].toUpperCase();
            
            if (!areaStats[areaCode]) {
                areaStats[areaCode] = { revenue: 0, volume: 0, orders: 0, profit: 0, prevRevenue: 0, prevVolume: 0, prevProfit: 0, returnedUnits: 0, totalPostage: 0, totalAdSpend: 0, platforms: {}, skus: {} };
            }

            const rev = calcRevenue(log);
            const profit = calcProfit(log);
            const units = calcUnits(log);

            // Aggregate District Level Data
            if (districtMatch) {
                const districtCode = districtMatch[1].toUpperCase();
                if (!districtStats[districtCode]) {
                    districtStats[districtCode] = { revenue: 0, volume: 0, profit: 0, totalPostage: 0 };
                }
                if (isDateKeyBetween(logKey, startKey, endKey)) {
                    districtStats[districtCode].revenue += rev;
                    districtStats[districtCode].volume += units;
                    districtStats[districtCode].profit += profit;
                    districtStats[districtCode].totalPostage += (product.postage || 0) * units;
                }
            }
            
            const area = areaStats[areaCode];
            const platform = log.platform || 'Unknown';
            const adSpend = calcAdSpend(log);
            
            if (isDateKeyBetween(logKey, startKey, endKey)) {
                // Top level stats
                area.revenue += rev;
                area.volume += units;
                area.orders += 1; // Assuming one log is one transaction/order
                area.profit += profit;
                const rowStatus = String((log as any).status || (log as any).orderStatus || '').toLowerCase();
                if (rowStatus.includes('return') || rowStatus.includes('refund')) {
                    area.returnedUnits += units > 0 ? units : 1;
                }
                area.totalPostage += (product.postage || 0) * units;
                area.totalAdSpend += adSpend;
                
                // Platform breakdown
                if (!area.platforms[platform]) area.platforms[platform] = { revenue: 0, volume: 0, profit: 0 };
                area.platforms[platform].revenue += rev;
                area.platforms[platform].volume += units;
                area.platforms[platform].profit += profit;

                // SKU breakdown
                if (!area.skus[sku]) area.skus[sku] = { name: product.name, profit: 0, volume: 0, revenue: 0 };
                area.skus[sku].profit += profit;
                area.skus[sku].volume += units;
                area.skus[sku].revenue += rev;

            } else if (isDateKeyBetween(logKey, prevStartKey, prevEndKey)) {
                area.prevRevenue += rev;
                area.prevVolume += units;
                area.prevProfit += profit;
            }
        });
    }

    return Object.entries(areaStats).map(([code, stats]) => {
        // Apply VAT Scaling to monetary aggregates
        assertNotAlreadyScaled('aggregateUkMapData:revenue', stats.revenue);
        const revenueInclTax = scaleMoneyInclTax(stats.revenue);
        const profitInclTax = scaleMoneyInclTax(stats.profit);
        const adSpendInclTax = scaleMoneyInclTax(stats.totalAdSpend);
        const totalPostageInclTax = scaleMoneyInclTax(stats.totalPostage);
        const prevRevenueInclTax = scaleMoneyInclTax(stats.prevRevenue);
        const prevProfitInclTax = scaleMoneyInclTax(stats.prevProfit);

        const platformBreakdown = Object.entries(stats.platforms)
            .map(([platform, data]) => ({ 
                platform, 
                revenue: scaleMoneyInclTax(data.revenue), 
                volume: data.volume, 
                profit: scaleMoneyInclTax(data.profit) 
            }))
            .sort((a, b) => b.revenue - a.revenue);
        
        const topSkus = Object.entries(stats.skus)
            .map(([sku, data]) => ({ 
                sku, 
                name: data.name, 
                profit: scaleMoneyInclTax(data.profit), 
                volume: data.volume, 
                revenue: scaleMoneyInclTax(data.revenue)
            }))
            .sort((a, b) => b.profit - a.profit)
            .slice(0, 3);

        const revenueDelta = revenueInclTax - prevRevenueInclTax;
        const volumeDelta = stats.volume - stats.prevVolume;
        const profitDelta = profitInclTax - prevProfitInclTax;
        
        const districtBreakdown = Object.entries(districtStats)
          .filter(([districtCode]) => {
              const prefixMatch = districtCode.match(/^[A-Z]+/);
              return prefixMatch && prefixMatch[0] === code;
          })
          .map(([districtCode, districtData]) => {
            const dRev = scaleMoneyInclTax(districtData.revenue);
            const dProf = scaleMoneyInclTax(districtData.profit);
            const dShip = scaleMoneyInclTax(districtData.totalPostage);
            return {
                code: districtCode,
                revenue: dRev,
                volume: districtData.volume,
                profit: dProf,
                totalShippingCost: dShip,
                avgShippingCost: districtData.volume > 0 ? dShip / districtData.volume : 0
            };
          })
          .sort((a, b) => b.revenue - a.revenue);
        const demographics = getAreaDemographics(code);

        return {
            code,
            incomeBand: demographics.incomeBand,
            householdProfile: demographics.householdProfile,
            deprivationDecile: demographics.deprivationDecile,
            ruralUrbanFlag: demographics.ruralUrbanFlag,
            revenue: revenueInclTax,
            volume: stats.volume,
            orders: stats.orders,
            profit: profitInclTax,
            margin: calcMarginPct(revenueInclTax, profitInclTax),
            returnRate: stats.volume > 0 ? (stats.returnedUnits / stats.volume) * 100 : 0,
            avgShippingCost: stats.volume > 0 ? totalPostageInclTax / stats.volume : 0,
            totalShippingCost: totalPostageInclTax,
            adSpend: adSpendInclTax,
            tacos: calcTACoSPct(adSpendInclTax, revenueInclTax),
            coordinates: POSTCODE_COORDS[code],
            platformBreakdown,
            topSkus,
            prevRevenue: prevRevenueInclTax,
            prevVolume: stats.prevVolume,
            prevProfit: prevProfitInclTax,
            revenueDelta,
            volumeDelta,
            profitDelta,
            revenueDeltaPct: prevRevenueInclTax > 0 ? (revenueDelta / prevRevenueInclTax) * 100 : (revenueDelta > 0 ? Infinity : 0),
            volumeDeltaPct: stats.prevVolume > 0 ? (volumeDelta / stats.prevVolume) * 100 : (volumeDelta > 0 ? Infinity : 0),
            profitDeltaPct: prevProfitInclTax > 0 ? (profitDelta / prevProfitInclTax) * 100 : (profitDelta > 0 ? Infinity : 0),
            districtBreakdown,
            moneyIsTaxInclusive: true
        };
    }).filter(d => d.coordinates);
};
