
import React, { startTransition, useState, useEffect, useCallback, Suspense, lazy } from 'react';
import { useAppState } from './hooks/useAppState';
import { QuickUploadMenu } from './components/shared/QuickUploadMenu';

import {
    LayoutDashboard, FlaskConical, BadgePoundSterling, Tag, Briefcase, Settings, BookOpen, Search, X,
    Download, Upload, Database, CheckCircle, FileBarChart, Bell, History,
    ChevronDown, RotateCcw, FileText, Link as LinkIcon, Ship, Store, Truck,
    ArrowUp, ShoppingBasket, Table, Lock, LogOut, RefreshCw, UploadCloud, Loader2, Target
} from 'lucide-react';

import GlobalSearch from './components/shared/GlobalSearch';
import UserProfile from './components/shared/UserProfile';
import { hexToRgb } from './utils/color';
import { StrategyConfig, OptimalPriceResult } from './types';
import { logPerf } from './services/pagePerf';

const OverviewPageContainer = lazy(() => import('./components/overview/OverviewPageContainer').then(m => ({ default: m.OverviewPageContainer })));
const ProductManagementPage = lazy(() => import('./components/productManagement/ProductManagementPage'));
const StrategyPage = lazy(() => import('./components/strategy/StrategyPage'));
const PlatformManagementPage = lazy(() => import('./components/platformManagement/PlatformManagementPage'));
const SearchResultsPage = lazy(() => import('./components/search/SearchResultsPage'));
const CostManagementPage = lazy(() => import('./components/costManagement/CostManagementPage'));
const PromotionPage = lazy(() => import('./components/promotionManager/PromotionPage'));
const ToolboxPage = lazy(() => import('./components/toolbox/ToolboxPageContainer'));
const DefinitionsPage = lazy(() => import('./components/definitions/DefinitionsPageContainer'));
const SettingsPage = lazy(() => import('./components/settings/SettingsPage'));
const CustomReportPage = lazy(() => import('./components/customReport/CustomReportPage').then(m => ({ default: m.CustomReportPage })));
const AdCampaignPageContainer = lazy(() => import('./components/adCampaign/AdCampaignPageContainer'));
const BatchUploadModal = lazy(() => import('./components/shared/modals/BatchUploadModal'));
const SalesImportModal = lazy(() => import('./components/shared/modals/SalesImportModal'));
const SkuDetailUploadModal = lazy(() => import('./components/shared/modals/SkuDetailUploadModal'));
const MappingUploadModal = lazy(() => import('./components/shared/modals/MappingUploadModal'));
const ReturnsUploadModal = lazy(() => import('./components/shared/modals/ReturnsUploadModal'));
const CAUploadModal = lazy(() => import('./components/shared/modals/CAUploadModal'));
const ShipmentUploadModal = lazy(() => import('./components/shared/modals/ShipmentUploadModal'));
const FreightUploadModal = lazy(() => import('./components/shared/modals/FreightUploadModal'));
const PriceElasticityModal = lazy(() => import('./components/skuDeepDive/PriceElasticityModal'));
const AnalysisModal = lazy(() => import('./components/skuDeepDive/AnalysisModal'));


const PageSpinner = () => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '16rem', opacity: 0.35 }}>
        <svg style={{ width: 28, height: 28, animation: 'spin 1s linear infinite' }} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83"/>
        </svg>
    </div>
);


// ── Admin Modal — own component so password typing doesn't re-render the whole app ──
interface AdminModalProps {
    onClose: () => void;
    onSuccess: () => void;
    handleAdminToggle: (pw: string) => Promise<{ success: boolean; error?: string }>;
}
const AdminModal: React.FC<AdminModalProps> = ({ onClose, onSuccess, handleAdminToggle }) => {
    const [password, setPassword] = React.useState('');
    const [error, setError] = React.useState('');

    const tryLogin = async () => {
        const r = await handleAdminToggle(password);
        if (r.success) { onSuccess(); } else { setError(r.error || 'Invalid password'); }
    };

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200">
                <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                    <h3 className="text-base font-bold text-gray-900">Enter Admin Mode</h3>
                    <button onClick={onClose} className="p-1.5 hover:bg-gray-200 rounded-full text-gray-400"><X className="w-4 h-4" /></button>
                </div>
                <div className="p-6 space-y-4">
                    <p className="text-sm text-gray-500">Enter the admin password to unlock push-to-database controls.</p>
                    <input
                        type="password"
                        value={password}
                        onChange={e => { setPassword(e.target.value); setError(''); }}
                        onKeyDown={async e => { if (e.key === 'Enter') await tryLogin(); }}
                        placeholder="Admin password..."
                        className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-theme outline-none transition-all text-sm"
                        autoFocus
                    />
                    {error && <p className="text-xs text-red-600 font-medium">{error}</p>}
                </div>
                <div className="p-6 border-t border-gray-100 bg-gray-50/50 flex justify-end gap-3">
                    <button onClick={onClose} className="px-5 py-2 text-gray-500 font-bold text-sm hover:text-gray-700">Cancel</button>
                    <button onClick={tryLogin} className="px-6 py-2 bg-theme hover:bg-theme text-white rounded-xl text-sm font-bold shadow-md transition-all opacity-90 hover:opacity-100">
                        Unlock
                    </button>
                </div>
            </div>
        </div>
    );
};

interface ReleaseNoteItem {
    id: string;
    date: string;
    summary: string;
}

const RELEASE_NOTES_SEEN_KEY = 'sello_release_notes_seen_id';
const APP_BOOT_START_MS = typeof performance !== 'undefined' ? performance.now() : Date.now();
const perfNowMs = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());
const PAGE_ORDER = ['search','products','platforms','strategy','costs','promotions','ad-campaigns','tools','definitions','settings','custom-report'];
const publishAppBusySignal = (reasons: Set<string>, meta: Record<string, unknown> = {}) => {
    if (typeof window === 'undefined') return;
    const activeReasons = Array.from(reasons.values());
    (window as any).__selloAppBusy = activeReasons.length > 0;
    (window as any).__selloAppBusyReasons = activeReasons;
    (window as any).__selloAppBusyUpdatedAt = perfNowMs();
    (window as any).__selloAppBusyMeta = meta;
};

const App: React.FC = () => {
    const {
        t,
        products,
        setProducts,
        salesHistory,
        refundHistory,
        freightRates,
        handleFreightRatesUpload,
        priceChangeHistory,
        costChangeHistory,
        inventoryChangeHistory,
        promotions,
        setPromotions,
        learnedAliases,
        setLearnedAliases,
        inventoryTemplates,
        setInventoryTemplates,
        customReportPresets,
        setCustomReportPresets,
        priceCheckTemplates,
        handleSavePriceCheckTemplates,
        pricingRules,
        setPricingRules,
        logisticsRules,
        setLogisticsRules,
        strategyRules,
        setStrategyRules,
        searchConfig,
        setSearchConfig,
        skuFamilies,
        setSkuFamilies,
        pendingFamilySuggestions,
        setPendingFamilySuggestions,
        adGroups,
        onSyncFromFamilies,
        onAddAdGroup,
        onEditAdGroup,
        onRemoveAdGroup,
        handleAdGroupSave,
        lastRecalculationSummary,
        brandMap,
        handleSaveBrandMap,
        categoryMap,
        handleSaveCategoryMap,
        uploadTimestamps,
        thresholds,
        velocityLookback,
        setVelocityLookback,
        userProfile,
        setUserProfile,
        showBackToTop,
        mainContentRef,
        fileRestoreRef,
        selectedElasticityProduct,
        setSelectedElasticityProduct,
        isUploadModalOpen,
        setIsUploadModalOpen,
        isSalesImportModalOpen,
        setIsSalesImportModalOpen,
        isSkuDetailModalOpen,
        setIsSkuDetailModalOpen,
        isMappingModalOpen,
        setIsMappingModalOpen,
        isReturnsModalOpen,
        setIsReturnsModalOpen,
        isCAUploadModalOpen,
        setIsCAUploadModalOpen,
        isShipmentModalOpen,
        setIsShipmentModalOpen,
        isFreightModalOpen,
        setIsFreightModalOpen,
        selectedAnalysisProduct,
        setSelectedAnalysisProduct,
        analysisResult,
        setAnalysisResult,
        isAnalysisLoading,
        isSearchLoading,
        searchSessions,
        activeSearchId,
        setActiveSearchId,
        currentView,
        setCurrentView,
        navigationIntent,
        navigateToEntity,
        clearNavigationIntent,
        isOnline,
        isFreshnessExpanded,
        setIsFreshnessExpanded,
        mapJumpState,
        setMapJumpState,
        priceHistoryMap,
        existingOrders,
        dynamicDateLabels,
        ambientRgb,
        handleRefreshThresholds,
        handleRecalculateVelocity,
        handleSearch,
        handleDeepDiveRequest,
        handleManualPriceChange,
        handleManualCostChange,
        handleAnalyzeCarrier,
        handleRefineSearch,
        deleteSearchSession,
        handleViewElasticity,
        handleAnalyze,
        handleApplyPrice,
        handleBackup,
        handleRestore,
        handleResetRefunds,
        handleUpdatePriceChangeRecord,
        handleUpdateCostChangeRecord,
        handleUpdateInventoryChangeRecord,
        handleSalesImportConfirm,
        handleInventoryImport,
        handleResetSalesData,
        handleSkuDetailImport,
        handleMappingImport,
        handleReturnsImport,
        handleCAImport,
        handleDescriptionImport,
        handleStampLandedAt,
        handleShipmentImport,
        // DB Sync
        isAdminMode,
        isDirty,
        syncStatus,
        lastSyncedAt,
        showSaveToast,
        pushProgress,
        pushTotal,
        syncStep,
        syncProgress,
        syncTotal,
        startupChoicePending,
        startupSyncMode,
        postApplySource,
        isRestoring,
        handleAdminToggle,
        handleAdminExit,
        handleAdminPush,
        handleSync,
        handleStartSyncNow,
        handleStartLocalOnly,
        // Optimal pricing
        cohortSnapshot,
        optimalPriceResults,
        benchmarkUpdateNotices,
        benchmarkRecalcState,
        handleRecalculateBenchmarks,
        handleCancelBenchmarkRecalculation,
        handleDismissBenchmarkRecalcState,
        // Ad Campaign
        adSnapshots,
        adRosterChanges,
        adBudgets,
        handleAdCampaignImport,
        handleAdRosterChange,
    } = useAppState();

    // Progressive page mounting — pages stagger-mount during browser idle time after initial render
    const [mountedPages, setMountedPages] = useState<Set<string>>(() => new Set<string>());
    const [, setHiddenPageWarmTick] = useState(0);
    const mountPerfRef = React.useRef<{
        schedulerStartedAt?: number;
        firstDataReadyLogged?: boolean;
        firstCurrentViewMounted?: boolean;
    }>({});
    const appBusyReasonsRef = React.useRef<Set<string>>(new Set<string>());
    const hiddenWarmCycleRef = React.useRef(0);
    const skipNextHiddenWarmRef = React.useRef(false);
    // Frozen props for background-mounted pages — only update when page is active
    // Prevents expensive useMemo recalcs in hidden pages when unrelated state changes
    const frozenPromotionsRef = React.useRef(promotions || []);
    if (currentView === 'strategy' || !mountedPages.has('strategy')) {
        frozenPromotionsRef.current = promotions || [];
    }
    const frozenPromoOverviewRef = React.useRef(promotions || []);
    if (currentView === 'overview' || !mountedPages.has('overview')) {
        frozenPromoOverviewRef.current = promotions || [];
    }

    const frozenPromoProductsRef = React.useRef(promotions || []);
    if (currentView === 'products' || !mountedPages.has('products')) {
        frozenPromoProductsRef.current = promotions || [];
    }

    const frozenPromoToolboxRef = React.useRef(promotions || []);

    // Freeze salesHistory for pages that don't need live updates
    const frozenSalesForAdRef = React.useRef(salesHistory || []);
    if (currentView === 'ad-campaigns') frozenSalesForAdRef.current = salesHistory || [];

    const frozenSalesForToolsRef = React.useRef(salesHistory || []);
    if (currentView === 'tools') frozenSalesForToolsRef.current = salesHistory || [];
    if (currentView === 'tools' || !mountedPages.has('tools')) {
        frozenPromoToolboxRef.current = promotions || [];
    }
    const searchPageDataRef = React.useRef({
        products,
        pricingRules,
        promotions: promotions || [],
        priceHistoryMap,
        optimalPriceResults,
        adGroups,
        skuFamilies
    });
    if (currentView === 'search' || !mountedPages.has('search')) {
        searchPageDataRef.current = {
            products,
            pricingRules,
            promotions: promotions || [],
            priceHistoryMap,
            optimalPriceResults,
            adGroups,
            skuFamilies
        };
    }
    const overviewPageDataRef = React.useRef({
        products,
        priceHistoryMap,
        refundHistory,
        pricingRules,
        priceChangeHistory,
        promotions: promotions || [],
        thresholds,
        mapJumpState
    });
    if (currentView === 'overview' || !mountedPages.has('overview')) {
        overviewPageDataRef.current = {
            products,
            priceHistoryMap,
            refundHistory,
            pricingRules,
            priceChangeHistory,
            promotions: promotions || [],
            thresholds,
            mapJumpState
        };
    }
    const productPageDataRef = React.useRef({
        products,
        pricingRules,
        promotions: promotions || [],
        priceHistoryMap,
        refundHistory: refundHistory || [],
        priceChangeHistory: priceChangeHistory || [],
        inventoryChangeHistory: inventoryChangeHistory || [],
        skuFamilies,
        pendingFamilySuggestions,
        cohortSnapshot,
        optimalPriceResults,
        benchmarkUpdateNotices,
        benchmarkRecalcState
    });
    if (currentView === 'products' || !mountedPages.has('products')) {
        productPageDataRef.current = {
            products,
            pricingRules,
            promotions: promotions || [],
            priceHistoryMap,
            refundHistory: refundHistory || [],
            priceChangeHistory: priceChangeHistory || [],
            inventoryChangeHistory: inventoryChangeHistory || [],
            skuFamilies,
            pendingFamilySuggestions,
            cohortSnapshot,
            optimalPriceResults,
            benchmarkUpdateNotices,
            benchmarkRecalcState
        };
    }
    const platformsPageDataRef = React.useRef({
        products,
        priceHistoryMap,
        refundHistory,
        pricingRules,
        adGroups,
        skuFamilies,
        lastRecalculationSummary
    });
    if (currentView === 'platforms' || !mountedPages.has('platforms')) {
        platformsPageDataRef.current = {
            products,
            priceHistoryMap,
            refundHistory,
            pricingRules,
            adGroups,
            skuFamilies,
            lastRecalculationSummary
        };
    }
    const strategyPageDataRef = React.useRef({
        products,
        pricingRules,
        refundHistory,
        promotions: promotions || [],
        priceHistoryMap,
        priceChangeHistory: priceChangeHistory || [],
        costChangeHistory: costChangeHistory || [],
        inventoryChangeHistory: inventoryChangeHistory || [],
        skuFamilies,
        optimalPriceResults
    });
    if (currentView === 'strategy' || !mountedPages.has('strategy')) {
        strategyPageDataRef.current = {
            products,
            pricingRules,
            refundHistory,
            promotions: promotions || [],
            priceHistoryMap,
            priceChangeHistory: priceChangeHistory || [],
            costChangeHistory: costChangeHistory || [],
            inventoryChangeHistory: inventoryChangeHistory || [],
            skuFamilies,
            optimalPriceResults
        };
    }
    const promotionsPageDataRef = React.useRef({
        products,
        pricingRules,
        logisticsRules: logisticsRules || [],
        promotions: promotions || [],
        priceHistoryMap
    });
    if (currentView === 'promotions' || !mountedPages.has('promotions')) {
        promotionsPageDataRef.current = {
            products,
            pricingRules,
            logisticsRules: logisticsRules || [],
            promotions: promotions || [],
            priceHistoryMap
        };
    }
    const adCampaignPageDataRef = React.useRef({
        products: products || [],
        salesHistory: salesHistory || [],
        adSnapshots: adSnapshots || [],
        adRosterChanges: adRosterChanges || [],
        adBudgets: adBudgets || {}
    });
    if (currentView === 'ad-campaigns' || !mountedPages.has('ad-campaigns')) {
        adCampaignPageDataRef.current = {
            products: products || [],
            salesHistory: salesHistory || [],
            adSnapshots: adSnapshots || [],
            adRosterChanges: adRosterChanges || [],
            adBudgets: adBudgets || {}
        };
    }
    const toolsPageDataRef = React.useRef({
        promotions: promotions || [],
        freightRates: freightRates || [],
        pricingRules,
        inventoryTemplates: inventoryTemplates || [],
        products: products || [],
        salesHistory: salesHistory || [],
        refundHistory: refundHistory || [],
        priceCheckTemplates: priceCheckTemplates || []
    });
    if (currentView === 'tools' || !mountedPages.has('tools')) {
        toolsPageDataRef.current = {
            promotions: promotions || [],
            freightRates: freightRates || [],
            pricingRules,
            inventoryTemplates: inventoryTemplates || [],
            products: products || [],
            salesHistory: salesHistory || [],
            refundHistory: refundHistory || [],
            priceCheckTemplates: priceCheckTemplates || []
        };
    }
    const customReportPageDataRef = React.useRef({
        products,
        priceHistory: salesHistory,
        refundHistory,
        pricingRules,
        customReportPresets
    });
    if (currentView === 'custom-report' || !mountedPages.has('custom-report')) {
        customReportPageDataRef.current = {
            products,
            priceHistory: salesHistory,
            refundHistory,
            pricingRules,
            customReportPresets
        };
    }
    const settingsPageDataRef = React.useRef({
        currentRules: pricingRules,
        logisticsRules: logisticsRules || [],
        products,
        freightRates: freightRates || [],
        searchConfig,
        velocityLookback,
        extraData: { priceHistory: salesHistory, promotions: promotions || [] },
        brandMap,
        categoryMap
    });
    if (currentView === 'settings' || !mountedPages.has('settings')) {
        settingsPageDataRef.current = {
            currentRules: pricingRules,
            logisticsRules: logisticsRules || [],
            products,
            freightRates: freightRates || [],
            searchConfig,
            velocityLookback,
            extraData: { priceHistory: salesHistory, promotions: promotions || [] },
            brandMap,
            categoryMap
        };
    }
    useEffect(() => {
        if (typeof window === 'undefined') return;
        (window as any).__selloActiveView = currentView;
        (window as any).__selloActiveViewUpdatedAt = perfNowMs();
    }, [currentView]);
    useEffect(() => {
        if (isRestoring) {
            skipNextHiddenWarmRef.current = true;
        }
    }, [isRestoring]);
    useEffect(() => {
        if (syncStatus !== 'idle' || isRestoring) return;
        if (skipNextHiddenWarmRef.current) {
            skipNextHiddenWarmRef.current = false;
            return;
        }
        if (postApplySource === 'refund-import' || postApplySource === 'sales-import' || postApplySource === 'inventory-import') return;
        if (mountedPages.size === 0) return;
        const hiddenPages = PAGE_ORDER.filter(page => page !== currentView && mountedPages.has(page));
        if (hiddenPages.length === 0) return;

        const cycle = hiddenWarmCycleRef.current + 1;
        const busyReasons = appBusyReasonsRef.current;
        hiddenWarmCycleRef.current = cycle;
        let index = 0;
        let timer: number | null = null;
        busyReasons.add('hidden-warm');
        publishAppBusySignal(busyReasons, {
            source: 'hidden-warm',
            cycle,
            hiddenPages
        });

        const warmPageSnapshot = (page: string) => {
            switch (page) {
                case 'search':
                    searchPageDataRef.current = {
                        products,
                        pricingRules,
                        promotions: promotions || [],
                        priceHistoryMap,
                        optimalPriceResults,
                        adGroups,
                        skuFamilies
                    };
                    break;
                case 'products':
                    productPageDataRef.current = {
                        products,
                        pricingRules,
                        promotions: promotions || [],
                        priceHistoryMap,
                        refundHistory: refundHistory || [],
                        priceChangeHistory: priceChangeHistory || [],
                        inventoryChangeHistory: inventoryChangeHistory || [],
                        skuFamilies,
                        pendingFamilySuggestions,
                        cohortSnapshot,
                        optimalPriceResults,
                        benchmarkUpdateNotices,
                        benchmarkRecalcState
                    };
                    break;
                case 'platforms':
                    platformsPageDataRef.current = {
                        products,
                        priceHistoryMap,
                        refundHistory,
                        pricingRules,
                        adGroups,
                        skuFamilies,
                        lastRecalculationSummary
                    };
                    break;
                case 'strategy':
                    strategyPageDataRef.current = {
                        products,
                        pricingRules,
                        refundHistory,
                        promotions: promotions || [],
                        priceHistoryMap,
                        priceChangeHistory: priceChangeHistory || [],
                        costChangeHistory: costChangeHistory || [],
                        inventoryChangeHistory: inventoryChangeHistory || [],
                        skuFamilies,
                        optimalPriceResults
                    };
                    break;
                case 'promotions':
                    promotionsPageDataRef.current = {
                        products,
                        pricingRules,
                        logisticsRules: logisticsRules || [],
                        promotions: promotions || [],
                        priceHistoryMap
                    };
                    break;
                case 'ad-campaigns':
                    adCampaignPageDataRef.current = {
                        products: products || [],
                        salesHistory: salesHistory || [],
                        adSnapshots: adSnapshots || [],
                        adRosterChanges: adRosterChanges || [],
                        adBudgets: adBudgets || {}
                    };
                    break;
                case 'tools':
                    toolsPageDataRef.current = {
                        promotions: promotions || [],
                        freightRates: freightRates || [],
                        pricingRules,
                        inventoryTemplates: inventoryTemplates || [],
                        products: products || [],
                        salesHistory: salesHistory || [],
                        refundHistory: refundHistory || [],
                        priceCheckTemplates: priceCheckTemplates || []
                    };
                    break;
                case 'custom-report':
                    customReportPageDataRef.current = {
                        products,
                        priceHistory: salesHistory,
                        refundHistory,
                        pricingRules,
                        customReportPresets
                    };
                    break;
                case 'settings':
                    settingsPageDataRef.current = {
                        currentRules: pricingRules,
                        logisticsRules: logisticsRules || [],
                        products,
                        freightRates: freightRates || [],
                        searchConfig,
                        velocityLookback,
                        extraData: { priceHistory: salesHistory, promotions: promotions || [] },
                        brandMap,
                        categoryMap
                    };
                    break;
                default:
                    break;
            }
        };

        const schedule = () => {
            if (hiddenWarmCycleRef.current !== cycle) return;
            if (index >= hiddenPages.length) {
                busyReasons.delete('hidden-warm');
                publishAppBusySignal(busyReasons, {
                    source: 'hidden-warm',
                    cycle,
                    hiddenPages,
                    completed: true
                });
                return;
            }
            const page = hiddenPages[index++];
            warmPageSnapshot(page);
            setHiddenPageWarmTick(tick => tick + 1);
            timer = window.setTimeout(schedule, 150);
        };

        timer = window.setTimeout(schedule, 1200);
        return () => {
            hiddenWarmCycleRef.current = cycle;
            busyReasons.delete('hidden-warm');
            publishAppBusySignal(busyReasons, {
                source: 'hidden-warm',
                cycle,
                cleanedUp: true
            });
            if (timer !== null) window.clearTimeout(timer);
        };
    }, [
        syncStatus,
        isRestoring,
        mountedPages,
        currentView,
        products,
        pricingRules,
        promotions,
        priceHistoryMap,
        optimalPriceResults,
        adGroups,
        skuFamilies,
        refundHistory,
        priceChangeHistory,
        inventoryChangeHistory,
        pendingFamilySuggestions,
        cohortSnapshot,
        benchmarkUpdateNotices,
        benchmarkRecalcState,
        lastRecalculationSummary,
        costChangeHistory,
        logisticsRules,
        adSnapshots,
        adRosterChanges,
        adBudgets,
        freightRates,
        inventoryTemplates,
        salesHistory,
        priceCheckTemplates,
        customReportPresets,
        searchConfig,
        velocityLookback,
        brandMap,
        categoryMap,
        postApplySource
    ]);
    const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(() => {
        try { return localStorage.getItem('sello_sidebar_collapsed') === 'true'; } catch { return false; }
    });
    const [navigationNotice, setNavigationNotice] = useState<string | null>(null);
    const toggleSidebar = () => setSidebarCollapsed(prev => {
        const next = !prev;
        try { localStorage.setItem('sello_sidebar_collapsed', String(next)); } catch { /* ignore localStorage write failures */ }
        return next;
    });

    // Optimal price curve modal state (extends useAppState's selectedElasticityProduct)
    const [elasticityResult, setElasticityResult] = useState<OptimalPriceResult | null>(null);
    const handleViewElasticityWithResult = (product: Parameters<typeof handleViewElasticity>[0], result?: OptimalPriceResult) => {
        setElasticityResult(result ?? null);
        handleViewElasticity(product);
    };
    const handleConsumeNavigationIntent = (result?: { success: boolean; message?: string }) => {
        clearNavigationIntent();
        if (result?.message) {
            setNavigationNotice(result.message);
        }
    };
    const hasAnyLocalData = (products?.length || 0) > 0 || (salesHistory?.length || 0) > 0 || (refundHistory?.length || 0) > 0;

    useEffect(() => {
        if (!navigationIntent) return;
        if (navigationIntent.targetView === 'promotions') {
            setCurrentView('promotions');
            return;
        }
        if (navigationIntent.targetView === 'overview' && navigationIntent.entityType === 'sales_map_carrier') {
            const carrier = navigationIntent.entityId.trim();
            if (!carrier) {
                setNavigationNotice('Carrier not found');
                clearNavigationIntent();
                return;
            }
            setMapJumpState({ carrier, metric: 'RETURN_RATE' });
            setCurrentView('overview');
            clearNavigationIntent();
            return;
        }
        if (navigationIntent.targetView === 'search' && navigationIntent.entityType === 'sku') {
            const targetSku = navigationIntent.entityId.trim().toLowerCase();
            const exists = (products || []).some(p => {
                if (!p || !p.sku) return false;
                if (p.sku.toLowerCase() === targetSku) return true;
                return (p.channels || []).some(c => c.skuAlias && c.skuAlias.split(',').some(a => a.trim().toLowerCase() === targetSku));
            });
            if (!exists) {
                setNavigationNotice('SKU not found');
                clearNavigationIntent();
                return;
            }
            handleDeepDiveRequest(navigationIntent.entityId);
            clearNavigationIntent();
        }
    }, [navigationIntent, setCurrentView, products, handleDeepDiveRequest, clearNavigationIntent, setMapJumpState]);

    useEffect(() => {
        if (!navigationNotice) return;
        const timer = window.setTimeout(() => setNavigationNotice(null), 2600);
        return () => window.clearTimeout(timer);
    }, [navigationNotice]);

    useEffect(() => {
        const schedulerStartedAt = perfNowMs();
        const busyReasons = appBusyReasonsRef.current;
        mountPerfRef.current.schedulerStartedAt = schedulerStartedAt;
        busyReasons.add('page-mount-scheduler');
        publishAppBusySignal(busyReasons, {
            source: 'page-mount-scheduler',
            pageOrderCount: PAGE_ORDER.length
        });
        logPerf('[perf][app-mount] scheduler start', {
            pageOrderCount: PAGE_ORDER.length,
            elapsedMs: Number((schedulerStartedAt - APP_BOOT_START_MS).toFixed(1))
        });
        let i = 0;
        let timer: number | null = null;
        const schedule = () => {
            if (i >= PAGE_ORDER.length) {
                busyReasons.delete('page-mount-scheduler');
                publishAppBusySignal(busyReasons, {
                    source: 'page-mount-scheduler',
                    pageOrderCount: PAGE_ORDER.length,
                    completed: true
                });
                return;
            }
            const page = PAGE_ORDER[i++];
            setMountedPages(prev => new Set([...prev, page]));
            logPerf('[perf][app-mount] page mounted', {
                page,
                mountedCount: i,
                elapsedMs: Number((perfNowMs() - schedulerStartedAt).toFixed(1)),
                sinceBootMs: Number((perfNowMs() - APP_BOOT_START_MS).toFixed(1))
            });
            timer = window.setTimeout(schedule, 25);
        };
        timer = window.setTimeout(schedule, 25);
        return () => {
            busyReasons.delete('page-mount-scheduler');
            publishAppBusySignal(busyReasons, {
                source: 'page-mount-scheduler',
                cleanedUp: true
            });
            if (timer !== null) {
                window.clearTimeout(timer);
            }
        };
    }, []);

    // Admin mode local UI state
    const [showAdminModal, setShowAdminModal] = useState(false);
    const [showExitConfirm, setShowExitConfirm] = useState(false);
    const [issueImportantRefresh, setIssueImportantRefresh] = useState(false);
    const [deductRefunds, setDeductRefunds] = useState(false);
    const [isReleaseNotesOpen, setIsReleaseNotesOpen] = useState(false);
    const [releaseNotes, setReleaseNotes] = useState<ReleaseNoteItem[]>([]);
    const [releaseNotesLoading, setReleaseNotesLoading] = useState(false);
    const [releaseNotesError, setReleaseNotesError] = useState<string | null>(null);
    const [releaseNotesSeenId, setReleaseNotesSeenId] = useState<string>(() => {
        try {
            return localStorage.getItem(RELEASE_NOTES_SEEN_KEY) || '';
        } catch {
            return '';
        }
    });
    const perfLoggedRef = React.useRef(false);
    const perfMarksRef = React.useRef<{
        shellRenderedAt?: number;
        firstDataReadyAt?: number;
        firstInteractiveAt?: number;
    }>({});
    const releaseNotesPopoverRef = React.useRef<HTMLDivElement | null>(null);

    const markReleaseNotesSeen = useCallback((noteId: string) => {
        if (!noteId) return;
        setReleaseNotesSeenId(noteId);
        try {
            localStorage.setItem(RELEASE_NOTES_SEEN_KEY, noteId);
        } catch {
            // ignore localStorage write failures
        }
    }, []);

    const quickUploadActions = [
        { label: t('quick_upload_inventory'), icon: Database, action: () => setIsUploadModalOpen(true), color: 'text-theme' },
        { label: t('quick_upload_sales'), icon: FileBarChart, action: () => setIsSalesImportModalOpen(true), color: 'text-blue-600' },
        { label: t('quick_upload_refunds'), icon: RotateCcw, action: () => setIsReturnsModalOpen(true), color: 'text-red-600' },
        { label: t('quick_upload_sku_detail'), icon: FileText, action: () => setIsSkuDetailModalOpen(true), color: 'text-teal-600' },
        { label: t('quick_upload_ca_report'), icon: Upload, action: () => setIsCAUploadModalOpen(true), color: 'text-purple-600' },
        { label: t('quick_upload_sku_mapping'), icon: LinkIcon, action: () => setIsMappingModalOpen(true), color: 'text-amber-600' },
        { label: t('quick_upload_shipment'), icon: Ship, action: () => setIsShipmentModalOpen(true), color: 'text-teal-600' },
        { label: 'Freight Costs', icon: Truck, action: () => setIsFreightModalOpen(true), color: 'text-emerald-600' },
    ];

    const headerTextColor = userProfile.textColor || '#111827';
    const textShadowStyle = userProfile.backgroundImage && userProfile.backgroundImage !== 'none' ? { textShadow: '0 1px 3px rgba(0,0,0,0.3)' } : {};
    const _themeRgb = (() => { const rgb = hexToRgb(userProfile.themeColor); return rgb ? `${rgb.r}, ${rgb.g}, ${rgb.b}` : '19, 78, 74'; })();
    const headerStyle = { color: headerTextColor, ...textShadowStyle };
    const hasInventory = products && products.length > 0;
    const activeSearch = (searchSessions || []).find(s => s.id === activeSearchId);

    const pageTitles: Record<string, string> = {
        search: t('header_search'),
        products: t('header_products'),
        platforms: t('header_platforms'),
        overview: t('header_dashboard'),
        strategy: t('header_strategy'),
        costs: t('header_costs'),
        definitions: t('header_definitions'),
        promotions: t('header_promotions'),
        tools: t('header_toolbox'),
        'family-groups': 'Family Groups',
        'custom-report': 'Custom Report Builder',
        'ad-campaigns': 'Ad Campaigns',
        settings: t('desc_settings'),
    };

    const pageDescs: Record<string, string> = {
        search: t('desc_search'),
        overview: t('desc_dashboard'),
        strategy: t('desc_strategy'),
        products: t('desc_products'),
        platforms: t('desc_platforms'),
        costs: t('desc_costs'),
        definitions: t('desc_definitions'),
        promotions: t('desc_promotions'),
        tools: t('desc_toolbox'),
        'family-groups': 'Manage SKU family groups for analytics',
        'custom-report': 'Build and save custom data views',
        'ad-campaigns': 'Track and manage ad group performance',
        settings: t('desc_settings'),
    };

    const latestReleaseNoteId = releaseNotes[0]?.id || '';
    const hasUnreadReleaseNotes = !!latestReleaseNoteId && latestReleaseNoteId !== releaseNotesSeenId;

    useEffect(() => {
        let active = true;
        setReleaseNotesLoading(true);
        setReleaseNotesError(null);

        fetch('/release-notes.json', { cache: 'no-store' })
            .then(async response => {
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                const payload = await response.json();
                if (!active) return;
                const items = Array.isArray(payload?.items) ? payload.items : [];
                const normalized = items
                    .filter((item: any) => item && typeof item.summary === 'string')
                    .map((item: any) => ({
                        id: String(item.id || ''),
                        date: String(item.date || ''),
                        summary: String(item.summary || '').trim()
                    }))
                    .filter((item: ReleaseNoteItem) => item.id && item.summary);
                setReleaseNotes(normalized);
            })
            .catch(() => {
                if (!active) return;
                setReleaseNotes([]);
                setReleaseNotesError('Unable to load updates');
            })
            .finally(() => {
                if (!active) return;
                setReleaseNotesLoading(false);
            });

        return () => { active = false; };
    }, []);

    useEffect(() => {
        if (!isReleaseNotesOpen) return;
        if (latestReleaseNoteId) {
            markReleaseNotesSeen(latestReleaseNoteId);
        }
    }, [isReleaseNotesOpen, latestReleaseNoteId, markReleaseNotesSeen]);

    useEffect(() => {
        if (!isReleaseNotesOpen) return;
        const onPointerDown = (event: MouseEvent) => {
            const target = event.target as Node;
            if (releaseNotesPopoverRef.current && !releaseNotesPopoverRef.current.contains(target)) {
                setIsReleaseNotesOpen(false);
            }
        };
        window.addEventListener('mousedown', onPointerDown);
        return () => window.removeEventListener('mousedown', onPointerDown);
    }, [isReleaseNotesOpen]);

    useEffect(() => {
        const markShellRendered = () => {
            const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
            if (!perfMarksRef.current.shellRenderedAt) {
                perfMarksRef.current.shellRenderedAt = now;
                (window as any).__selloPerf = {
                    ...((window as any).__selloPerf || {}),
                    appBootStartAt: APP_BOOT_START_MS,
                    appShellRenderedAt: now
                };
                logPerf(`[perf] app_shell_rendered: ${(now - APP_BOOT_START_MS).toFixed(1)}ms`);
            }
        };
        if (typeof requestAnimationFrame !== 'undefined') {
            requestAnimationFrame(markShellRendered);
        } else {
            setTimeout(markShellRendered, 0);
        }
    }, []);

    useEffect(() => {
        const hasAnyData = (products?.length || 0) > 0 || (salesHistory?.length || 0) > 0 || (refundHistory?.length || 0) > 0;
        if (hasAnyData && syncStatus === 'idle' && !mountPerfRef.current.firstDataReadyLogged) {
            mountPerfRef.current.firstDataReadyLogged = true;
            logPerf('[perf][app-mount] data-ready gate opened', {
                currentView,
                mountedCurrentView: mountedPages.has(currentView),
                mountedCount: mountedPages.size,
                products: products?.length || 0,
                salesHistory: salesHistory?.length || 0,
                refunds: refundHistory?.length || 0,
                elapsedMs: Number((perfNowMs() - APP_BOOT_START_MS).toFixed(1))
            });
        }
        if (syncStatus === 'idle' && hasAnyData && !perfMarksRef.current.firstDataReadyAt) {
            const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
            perfMarksRef.current.firstDataReadyAt = now;
            (window as any).__selloPerf = {
                ...((window as any).__selloPerf || {}),
                firstViewDataReadyAt: now
            };
            logPerf(`[perf] first_view_data_ready: ${(now - APP_BOOT_START_MS).toFixed(1)}ms`);
        }
    }, [syncStatus, products, salesHistory, refundHistory, mountedPages, currentView]);

    useEffect(() => {
        if (mountedPages.has(currentView) && !mountPerfRef.current.firstCurrentViewMounted) {
            mountPerfRef.current.firstCurrentViewMounted = true;
            logPerf('[perf][app-mount] current view mounted', {
                currentView,
                mountedCount: mountedPages.size,
                elapsedMs: Number((perfNowMs() - APP_BOOT_START_MS).toFixed(1))
            });
        }
    }, [mountedPages, currentView]);

    useEffect(() => {
        if (perfLoggedRef.current) return;
        if (!perfMarksRef.current.firstDataReadyAt) return;
        if (!mountedPages.has(currentView)) return;

        logPerf('[perf][app-mount] interactive gate opened', {
            currentView,
            mountedCount: mountedPages.size,
            dataReadyElapsedMs: Number(((perfMarksRef.current.firstDataReadyAt || perfNowMs()) - APP_BOOT_START_MS).toFixed(1)),
            elapsedMs: Number((perfNowMs() - APP_BOOT_START_MS).toFixed(1))
        });

        const stampInteractive = () => {
            if (perfLoggedRef.current) return;
            const now = typeof performance !== 'undefined' ? performance.now() : Date.now();
            perfMarksRef.current.firstInteractiveAt = now;
            const shellMs = (perfMarksRef.current.shellRenderedAt || now) - APP_BOOT_START_MS;
            const dataReadyMs = (perfMarksRef.current.firstDataReadyAt || now) - APP_BOOT_START_MS;
            const interactiveMs = now - APP_BOOT_START_MS;
            const readyToInteractiveMs = now - (perfMarksRef.current.firstDataReadyAt || now);
            perfLoggedRef.current = true;
            (window as any).__selloPerf = {
                ...((window as any).__selloPerf || {}),
                firstInteractiveAt: now,
                summary: {
                    shellMs: Number(shellMs.toFixed(1)),
                    dataReadyMs: Number(dataReadyMs.toFixed(1)),
                    interactiveMs: Number(interactiveMs.toFixed(1)),
                    readyToInteractiveMs: Number(readyToInteractiveMs.toFixed(1))
                }
            };
            logPerf(
                `[perf] startup_summary shell=${shellMs.toFixed(1)}ms data_ready=${dataReadyMs.toFixed(1)}ms ` +
                `interactive=${interactiveMs.toFixed(1)}ms ready_to_interactive=${readyToInteractiveMs.toFixed(1)}ms`
            );
        };

        if (typeof requestAnimationFrame !== 'undefined') {
            requestAnimationFrame(() => requestAnimationFrame(stampInteractive));
        } else {
            setTimeout(stampInteractive, 0);
        }
    }, [mountedPages, currentView]);

    return (
        <>
            <style>{`html, body { height: 100%; margin: 0; padding: 0; overflow: hidden; } :root { --glass-bg: ${userProfile.glassMode === 'dark' ? `rgba(17, 24, 39, ${(userProfile.glassOpacity ?? 90) / 100})` : `rgba(255, 255, 255, ${(userProfile.glassOpacity ?? 90) / 100})`}; --glass-border: ${userProfile.glassMode === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(255, 255, 255, 0.4)'}; --glass-blur: blur(${userProfile.glassBlur ?? 10}px); --glass-bg-modal: ${userProfile.glassMode === 'dark' ? `rgba(17, 24, 39, ${Math.min(1, (userProfile.glassOpacity ?? 90) / 100 + 0.1)})` : `rgba(255, 255, 255, ${Math.min(1, (userProfile.glassOpacity ?? 90) / 100 + 0.1)})`}; --glass-blur-modal: blur(${Math.min(40, (userProfile.glassBlur ?? 10) + 8)}px); --ambient-bg: rgba(${ambientRgb.r}, ${ambientRgb.g}, ${ambientRgb.b}, ${(userProfile.ambientGlassOpacity ?? 15) / 100}); --ambient-blur: blur(${Math.min(20, (userProfile.glassBlur ?? 10) + 4)}px); --glass-header-bg: rgba(249,250,251,0.97); --glass-row-even: rgba(249,250,251,0.30); --glass-row-hover: rgba(243,244,246,0.60); --glass-divider: rgba(229,231,235,0.55); --theme: ${userProfile.themeColor}; --theme-rgb: ${_themeRgb}; --theme-10: rgba(${_themeRgb}, 0.10); --theme-20: rgba(${_themeRgb}, 0.20); } .bg-custom-glass { background-color: var(--glass-bg); backdrop-filter: var(--glass-blur); -webkit-backdrop-filter: var(--glass-blur); } .border-custom-glass { border-color: var(--glass-border); } .bg-custom-glass-modal { background-color: var(--glass-bg-modal); } .backdrop-blur-custom-modal { backdrop-filter: var(--glass-blur-modal); -webkit-backdrop-filter: var(--glass-blur-modal); } .bg-custom-ambient { background-color: var(--ambient-bg); } .backdrop-blur-custom-ambient { backdrop-filter: var(--ambient-blur); -webkit-backdrop-filter: var(--ambient-blur); }`}</style>
            {startupChoicePending && !hasAnyLocalData && (
                <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/35 backdrop-blur-sm p-4">
                    <div className="w-full max-w-lg bg-custom-glass-modal backdrop-blur-custom-modal border border-custom-glass rounded-2xl shadow-2xl p-6 space-y-5">
                        <div>
                            <div className="text-xs font-bold uppercase tracking-[0.18em] text-gray-400">Startup</div>
                            <h2 className="mt-2 text-2xl font-bold text-gray-900">Choose how to start</h2>
                            <p className="mt-2 text-sm text-gray-600">
                                Auto-sync is paused. Start from the database, stay on local data, or restore a backup before any sync runs.
                            </p>
                        </div>
                        <div className="grid gap-3">
                            <button
                                onClick={handleStartSyncNow}
                                className="w-full rounded-xl border border-theme-20 bg-theme-10 px-4 py-3 text-left hover:bg-theme-10 transition-colors"
                            >
                                <div className="flex items-center gap-2 text-sm font-bold text-theme">
                                    <RefreshCw className="w-4 h-4" />
                                    Sync from database
                                </div>
                                <div className="mt-1 text-xs text-gray-500">Run the normal startup sync now.</div>
                            </button>
                            <button
                                onClick={handleStartLocalOnly}
                                className="w-full rounded-xl border border-custom-glass bg-white/70 px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                            >
                                <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
                                    <Database className="w-4 h-4" />
                                    Stay local only
                                </div>
                                <div className="mt-1 text-xs text-gray-500">Start fresh and upload new report.</div>
                            </button>
                            <button
                                onClick={() => fileRestoreRef.current?.click()}
                                className="w-full rounded-xl border border-custom-glass bg-white/70 px-4 py-3 text-left hover:bg-gray-50 transition-colors"
                            >
                                <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
                                    <Upload className="w-4 h-4" />
                                    Restore from backup first
                                </div>
                                <div className="mt-1 text-xs text-gray-500">Select a JSON backup before any database sync runs.</div>
                            </button>
                        </div>
                    </div>
                </div>
            )}
            <div className="h-screen flex font-sans text-gray-900 transition-colors duration-500 relative bg-transparent">
                {userProfile.ambientGlass && <div className="fixed inset-0 z-[1] pointer-events-none transition-all duration-500 bg-custom-ambient backdrop-blur-custom-ambient" />}
                <div className="group/sidebar hidden md:block fixed h-full z-40" style={{ width: sidebarCollapsed ? 64 : 240, transition: 'width 300ms' }}>
                <aside className="w-full h-full flex flex-col border-r border-custom-glass shadow-sm bg-custom-glass">
                    <div className="h-[60px] flex items-center px-3 gap-6 border-b border-custom-glass">
                        <div className="w-7 h-7 rounded-lg flex items-center justify-center text-white font-bold text-sm flex-shrink-0" style={{ backgroundColor: userProfile.themeColor, marginLeft: '6px' }}>S</div>
                        <span
                            className="overflow-hidden whitespace-nowrap transition-[width,opacity] duration-300 ease-in-out"
                            style={{
                                width: sidebarCollapsed ? 0 : '160px',
                                opacity: sidebarCollapsed ? 0 : 1,
                                marginLeft: sidebarCollapsed ? 0 : '0px',
                            }}
                        >
                            <span className="font-bold text-lg tracking-tight text-gray-900 whitespace-nowrap">Sello UK Hub</span>
                        </span>
                    </div>
                    <nav className="flex-1 px-3 py-2 space-y-0.5 overflow-y-auto">
                        {[
                            { id: 'overview', icon: LayoutDashboard, label: t('nav_overview') },
                            { id: 'products', icon: ShoppingBasket, label: t('nav_products') },
                            { id: 'platforms', icon: Store, label: t('nav_platforms') },
                            { id: 'strategy', icon: FlaskConical, label: t('nav_strategy') },
                            { id: 'costs', icon: BadgePoundSterling, label: t('nav_costs') },
                            { id: 'promotions', icon: Tag, label: t('nav_promotions') },
                            { id: 'ad-campaigns', icon: Target, label: 'Ad Campaigns' },
                            { id: 'custom-report', icon: Table, label: 'Custom Reports' },
                            { id: 'tools', icon: Briefcase, label: t('nav_toolbox') },
                            { id: 'settings', icon: Settings, label: t('nav_config') },
                            { id: 'definitions', icon: BookOpen, label: t('nav_definitions') }
                        ].map((item) => {
                            const isActive = currentView === item.id;
                            return (
                                <div key={item.id}>
                                    <button
                                        onClick={() => setCurrentView(item.id as any)}
                                        className={`w-full flex items-center px-3 py-2 rounded-lg font-medium text-sm transition-colors duration-150 ${isActive ? 'bg-opacity-10' : 'text-gray-500'}`}
                                        style={isActive
                                            ? { backgroundColor: `${userProfile.themeColor}15`, color: userProfile.themeColor }
                                            : undefined}
                                        onMouseEnter={e => { if (!isActive) { (e.currentTarget as HTMLElement).style.backgroundColor = `${userProfile.themeColor}12`; (e.currentTarget as HTMLElement).style.color = userProfile.themeColor; } }}
                                        onMouseLeave={e => { if (!isActive) { (e.currentTarget as HTMLElement).style.backgroundColor = ''; (e.currentTarget as HTMLElement).style.color = ''; } }}
                                    >
                                        <span className="w-4 h-4 flex-shrink-0 flex items-center justify-center">
                                            <item.icon className="w-4 h-4" />
                                        </span>
                                        <span
                                            className="overflow-hidden whitespace-nowrap transition-[width,opacity] duration-300 ease-in-out"
                                            style={{
                                                width: sidebarCollapsed ? 0 : 'auto',
                                                opacity: sidebarCollapsed ? 0 : 1,
                                                marginLeft: sidebarCollapsed ? 0 : '30px',
                                            }}
                                        >
                                            {item.label}
                                        </span>
                                    </button>
                                </div>
                            );
                        })}
                        {searchSessions && searchSessions.length > 0 && (
                            <div className={`mt-4 pt-3 border-t border-gray-100/50 ${sidebarCollapsed ? 'px-1' : ''}`}>
                                {sidebarCollapsed ? (
                                    <div className="flex justify-center mb-1 text-gray-400" title={t('active_searches')}>
                                        <History className="w-3 h-3" />
                                    </div>
                                ) : (
                                    <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 px-2 flex items-center gap-2">
                                        <History className="w-3 h-3" />
                                        {t('active_searches')}
                                    </div>
                                )}
                                <div className="space-y-0.5">
                                    {searchSessions.map(session => (
                                        <div key={session.id} className="group relative flex items-center">
                                            <button
                                                onClick={() => { setActiveSearchId(session.id); setCurrentView('search'); }}
                                                className={`${sidebarCollapsed ? 'w-full h-8 justify-center px-0 py-0' : 'w-full gap-3 px-3 py-1.5 text-left'} flex items-center rounded-lg text-xs font-medium transition-all overflow-hidden ${activeSearchId === session.id && currentView === 'search' ? 'bg-white/40 shadow-sm' : 'text-gray-600 hover:bg-gray-100/50'}`}
                                                style={activeSearchId === session.id && currentView === 'search' ? { backgroundColor: `${userProfile.themeColor}15`, color: userProfile.themeColor } : {}}
                                                title={sidebarCollapsed ? session.query : undefined}
                                            >
                                                <Search className={`w-3.5 h-3.5 flex-shrink-0 ${activeSearchId === session.id && currentView === 'search' ? '' : 'opacity-70'}`} />
                                                {!sidebarCollapsed && <span className="truncate pr-4 block w-full">{session.query}</span>}
                                            </button>
                                            {!sidebarCollapsed && (
                                                <button
                                                    onClick={(e) => deleteSearchSession(session.id, e)}
                                                    className="absolute right-1 p-1 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full opacity-0 group-hover:opacity-100 transition-all z-10"
                                                    title="Close Search"
                                                >
                                                    <X className="w-2.5 h-2.5" />
                                                </button>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}
                    </nav>
                    <div className={`border-t border-custom-glass space-y-2 ${sidebarCollapsed ? 'p-2' : 'p-3'}`}>
                        {!sidebarCollapsed && <div className="px-1 flex gap-1">
                            <button
                                onClick={handleBackup}
                                disabled={syncStatus === 'syncing' || syncStatus === 'pushing'}
                                className="flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5 rounded-lg text-[10px] font-bold text-gray-600 hover:bg-gray-100/50 transition-colors border border-custom-glass disabled:opacity-40 disabled:cursor-not-allowed"
                            >
                                <Download className="w-3 h-3" /> {t('backup_db')}
                            </button>
                            <button
                                onClick={() => fileRestoreRef.current?.click()}
                                disabled={syncStatus === 'syncing' || syncStatus === 'pushing'}
                                className="flex-1 flex items-center justify-center gap-1.5 px-2 py-1.5 rounded-lg text-[10px] font-bold text-gray-600 hover:bg-gray-100/50 transition-colors border border-custom-glass disabled:opacity-40 disabled:cursor-not-allowed"
                            >
                                <Upload className="w-3 h-3" /> {t('restore_db')}
                            </button>
                            <input ref={fileRestoreRef} type="file" accept=".json" className="hidden" onChange={handleRestore} />
                        </div>}
                        {sidebarCollapsed && <input ref={fileRestoreRef} type="file" accept=".json" className="hidden" onChange={handleRestore} />}
                        {!sidebarCollapsed && <button
                            onClick={handleSync}
                            disabled={syncStatus === 'pushing' || syncStatus === 'syncing'}
                            className={`w-full flex flex-col items-center justify-center gap-0.5 px-2 py-2 rounded-lg text-[10px] font-bold transition-all border ${syncStatus === 'error'
                                ? 'text-red-600 border-red-200 bg-red-50/50 hover:bg-red-50'
                                : 'text-theme border-theme-20 bg-theme-10 hover:bg-theme-10'
                                } disabled:opacity-40 disabled:cursor-not-allowed`}
                        >
                            <div className="flex items-center gap-1.5 w-full">
                                {syncStatus === 'syncing' ? (
                                    <div className="flex flex-col items-center gap-1 w-full">
                                        <div className="flex items-center gap-1.5">
                                            <Loader2 className="w-3 h-3 animate-spin" />
                                            <span>
                                                {syncTotal > 0
                                                    ? `Syncing ${Math.round((syncProgress / syncTotal) * 100)}%`
                                                    : 'Syncing...'}
                                            </span>
                                        </div>
                                        {syncTotal > 0 && (
                                            <div className="w-full bg-gray-200 rounded-full h-1">
                                                <div
                                                    className="bg-theme rounded-full h-1 transition-all duration-300"
                                                    style={{ width: `${Math.round((syncProgress / syncTotal) * 100)}%` }}
                                                />
                                            </div>
                                        )}
                                        {syncStep ? (
                                            <span className="text-[9px] font-normal opacity-75 text-center leading-tight">
                                                {syncStep}
                                            </span>
                                        ) : null}
                                    </div>
                                ) : syncStatus === 'error' ? (
                                    <><RefreshCw className="w-3 h-3" /> Sync Failed — Retry</>
                                ) : (
                                    <><RefreshCw className="w-3 h-3" /> SYNC DATA</>
                                )}
                            </div>
                            {lastSyncedAt && syncStatus === 'idle' && (
                                <span className="text-[8px] text-gray-400 font-normal">
                                    {new Date(lastSyncedAt).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                                </span>
                            )}
                        </button>}
                        {!sidebarCollapsed && <div className="bg-gray-50/50 rounded-lg border border-custom-glass overflow-hidden transition-all duration-300">
                            <button onClick={() => setIsFreshnessExpanded(!isFreshnessExpanded)} className="w-full flex justify-between items-center p-2 hover:bg-gray-100/50 transition-colors">
                                <div className="flex items-center gap-2">
                                    <span className="text-[9px] font-bold text-gray-500 uppercase tracking-wide">Data Freshness</span>
                                    <ChevronDown className={`w-2.5 h-2.5 text-gray-400 transition-transform duration-200 ${isFreshnessExpanded ? 'rotate-180' : ''}`} />
                                </div>
                                <span className={`w-1 h-1 rounded-full ${isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></span>
                            </button>
                            {isFreshnessExpanded && (
                                <div className="px-2 pb-2 space-y-1 pt-0 animate-in slide-in-from-top-1 duration-200 text-[9px]">
                                    <div className="border-t border-gray-200/50 mb-1.5"></div>
                                    {[
                                        { label: 'Inventory', key: 'Inventory' },
                                        { label: 'Sales', key: 'Sales' },
                                        { label: 'SKU Detail', key: 'SKU Details' },
                                        { label: 'Refunds', key: 'Refunds' },
                                        { label: 'CA Prices', key: 'CA Prices' },
                                        { label: 'Shipments', key: 'Shipments' },
                                    ].map(item => (
                                        <div key={item.key} className="flex justify-between items-center">
                                            <span className="text-gray-500">{item.label}</span>
                                            <span className={`font-mono ${uploadTimestamps[item.key] ? 'text-gray-700 font-medium' : 'text-gray-300 italic'}`}>
                                                {uploadTimestamps[item.key] ? new Date(uploadTimestamps[item.key]).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' }) : '-'}
                                            </span>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>}
                    </div>
                </aside>
                {/* Floating sidebar toggle — appears on hover at vertical centre of sidebar edge */}
                <button
                    onClick={toggleSidebar}
                    className="absolute top-1/2 -translate-y-1/2 -right-3 w-6 h-6 rounded-full border border-custom-glass bg-white shadow-md flex items-center justify-center text-gray-400 hover:text-gray-700 hover:shadow-lg transition-all duration-150 opacity-0 group-hover/sidebar:opacity-100 z-50"
                    title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
                >
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                        {sidebarCollapsed
                            ? <path d="M9 18l6-6-6-6"/>
                            : <path d="M15 18l-6-6 6-6"/>
                        }
                    </svg>
                </button>
                </div>
                <main className={`flex-1 ${sidebarCollapsed ? 'md:ml-16' : 'md:ml-60'} min-0 relative z-10 flex flex-col h-full overflow-hidden transition-all duration-300`}>
                    <header className={`fixed top-0 right-0 z-50 flex items-center gap-4 px-6 h-[60px] bg-custom-glass border-b border-custom-glass/50 shadow-sm transition-all duration-300 ${sidebarCollapsed ? 'left-16' : 'left-60'}`}>
                        <div className="flex items-center gap-2 min-w-0">
                            <h1 className="text-sm font-bold transition-colors whitespace-nowrap" style={headerStyle}>
                                {pageTitles[currentView] || pageTitles.settings}
                            </h1>
                            <span className="text-gray-300 text-xs">·</span>
                            <p className="text-xs truncate" style={{ ...headerStyle, opacity: 0.6 }}>
                                {pageDescs[currentView] || pageDescs.settings}
                            </p>
                        </div>
                        <div className="flex-1 max-w-2xl"> <GlobalSearch onSearch={handleSearch} isLoading={isSearchLoading} platforms={Object.keys(pricingRules)} products={products} /> </div>
                        <div className="flex items-center gap-3">
                                {userProfile.name && <span className="text-xs font-semibold" style={headerStyle}>{t('hello')}, {userProfile.name}!</span>}
                                {hasInventory && <QuickUploadMenu themeColor={userProfile.themeColor} actions={quickUploadActions} />}
                                <div className="relative" ref={releaseNotesPopoverRef}>
                                    <button
                                        onClick={() => setIsReleaseNotesOpen(prev => !prev)}
                                        className="relative p-1.5 hover:opacity-70 transition-opacity"
                                        style={headerStyle}
                                        title="What's New"
                                    >
                                        <Bell className="w-4 h-4" />
                                        {hasUnreadReleaseNotes && (
                                            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-red-500 border border-white" />
                                        )}
                                    </button>
                                    {isReleaseNotesOpen && (
                                        <div className="absolute right-0 mt-2 w-[360px] max-h-[420px] overflow-y-auto rounded-xl border border-custom-glass bg-custom-glass shadow-xl backdrop-blur-custom p-3 z-[210]">
                                            <div className="flex items-center justify-between mb-2 px-1">
                                                <h3 className="text-xs font-bold text-gray-800 uppercase tracking-wide">Update Summary</h3>
                                                <button
                                                    onClick={() => setIsReleaseNotesOpen(false)}
                                                    className="text-xs text-gray-500 hover:text-gray-700"
                                                >
                                                    Close
                                                </button>
                                            </div>
                                            {releaseNotesLoading ? (
                                                <div className="text-xs text-gray-500 px-1 py-2">Loading updates...</div>
                                            ) : releaseNotesError ? (
                                                <div className="text-xs text-red-600 px-1 py-2">{releaseNotesError}</div>
                                            ) : releaseNotes.length === 0 ? (
                                                <div className="text-xs text-gray-500 px-1 py-2">No updates available.</div>
                                            ) : (
                                                <div className="space-y-2">
                                                    {releaseNotes.map(note => (
                                                        <div key={note.id} className="rounded-lg border border-gray-200/70 bg-white/70 px-3 py-2">
                                                            <div className="text-[11px] font-semibold text-gray-500 mb-1">
                                                                {new Date(note.date).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}
                                                            </div>
                                                            <p className="text-xs text-gray-800 leading-relaxed">{note.summary}</p>
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                </div>
                                <div className="h-4 w-px" style={{ backgroundColor: `${headerTextColor}40` }}></div>

                                {/* Admin Mode Controls */}
                                {isAdminMode ? (
                                    <div className="flex items-center gap-2">
                                        {/* Push to Database Button */}
                                        <button
                                            onClick={() => {
                                                handleAdminPush(issueImportantRefresh);
                                                if (issueImportantRefresh) setIssueImportantRefresh(false);
                                            }}
                                            disabled={(!isDirty && syncStatus === 'idle') || syncStatus === 'pushing'}
                                            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold transition-all border shadow-sm ${syncStatus === 'pushing'
                                                ? 'bg-theme-10 text-theme border-theme-20 cursor-wait'
                                                : syncStatus === 'error'
                                                    ? 'bg-red-50 text-red-600 border-red-200 hover:bg-red-100 cursor-pointer'
                                                    : !isDirty
                                                        ? 'bg-gray-50 text-gray-400 border-gray-200 cursor-not-allowed'
                                                        : 'bg-theme text-white border-theme hover:opacity-90 cursor-pointer'
                                                }`}
                                        >
                                            {syncStatus === 'pushing' ? (
                                                <div className="flex flex-col items-center gap-1 w-full min-w-[120px]">
                                                    <div className="flex items-center gap-1.5 text-xs font-bold">
                                                        <Loader2 className="w-3 h-3 animate-spin" />
                                                        {pushTotal > 0
                                                            ? `Pushing... ${Math.round((pushProgress / pushTotal) * 100)}%`
                                                            : 'Pushing...'}
                                                    </div>
                                                    {pushTotal > 0 && (
                                                        <div className="w-full bg-white/30 rounded-full h-1">
                                                            <div
                                                                className="bg-white rounded-full h-1 transition-all duration-300"
                                                                style={{ width: `${Math.round((pushProgress / pushTotal) * 100)}%` }}
                                                            />
                                                        </div>
                                                    )}
                                                </div>
                                            ) : syncStatus === 'error' ? (
                                                <><RefreshCw className="w-3.5 h-3.5" /> Push Failed — Retry</>
                                            ) : (
                                                <><UploadCloud className="w-3.5 h-3.5" /> Push to Database</>
                                            )}
                                        </button>
                                        <label className="flex items-center gap-1.5 px-2 py-1 rounded-lg border border-amber-200 bg-amber-50 text-[10px] font-bold text-amber-700">
                                            <input
                                                type="checkbox"
                                                checked={issueImportantRefresh}
                                                onChange={(e) => setIssueImportantRefresh(e.target.checked)}
                                                className="w-3 h-3 accent-amber-600"
                                            />
                                            Reset Token
                                        </label>
                                        {/* Admin Mode Pill */}
                                        <button
                                            onClick={() => {
                                                const result = handleAdminExit();
                                                if (result.needsConfirmation) setShowExitConfirm(true);
                                            }}
                                            className="flex items-center gap-1.5 px-3 py-1 bg-green-50 text-green-700 border border-green-200 rounded-lg text-xs font-bold hover:bg-green-100 transition-all shadow-sm"
                                        >
                                            <Lock className="w-3 h-3" />
                                            ADMIN MODE
                                            <LogOut className="w-3 h-3 opacity-60" />
                                        </button>
                                    </div>
                                ) : (
                                    <button
                                        onClick={() => setShowAdminModal(true)}
                                        className="flex items-center gap-1.5 px-3 py-1 bg-gray-100/60 text-gray-500 border border-gray-200 rounded-lg text-[10px] font-bold hover:bg-gray-200/60 transition-all"
                                    >
                                        <Lock className="w-3 h-3" />
                                        USER MODE
                                    </button>
                                )}

                                <UserProfile profile={userProfile} onUpdate={setUserProfile} />
                        </div>
                    </header>
                    <div className="h-[60px] shrink-0" />
                    <div ref={mainContentRef} className="flex-1 overflow-y-auto relative p-4 md:p-8">
                        {isRestoring ? (
                            <div className="flex flex-col items-center justify-center min-h-[500px] bg-custom-glass rounded-2xl border border-custom-glass text-center p-12 h-full">
                                <div
                                    className="w-20 h-20 rounded-full flex items-center justify-center mb-6 shadow-sm"
                                    style={{ backgroundColor: `${userProfile.themeColor}15`, color: userProfile.themeColor }}
                                >
                                    <Loader2 className="w-10 h-10 animate-spin" />
                                </div>
                                <h3 className="text-2xl font-bold text-gray-900">Restoring backup...</h3>
                                <p className="text-gray-500 max-w-lg mt-3 text-base">
                                    {syncStep || 'Applying restored data. Heavy pages stay paused until restore completes.'}
                                </p>
                                {syncTotal > 0 && (
                                    <div className="w-full max-w-md mt-8">
                                        <div className="flex justify-between text-xs text-gray-400 mb-2">
                                            <span>{syncStep || 'Restoring backup...'}</span>
                                            <span>{Math.round((syncProgress / syncTotal) * 100)}%</span>
                                        </div>
                                        <div className="w-full bg-gray-200 rounded-full h-2">
                                            <div
                                                className="rounded-full h-2 transition-all duration-300"
                                                style={{
                                                    width: `${Math.round((syncProgress / syncTotal) * 100)}%`,
                                                    backgroundColor: userProfile.themeColor
                                                }}
                                            />
                                        </div>
                                    </div>
                                )}
                            </div>
                        ) : (
                            <>
                        {/* Spinner shown when user navigates to a page before it has mounted */}
                        {!mountedPages.has(currentView) && currentView !== 'overview' && currentView !== 'custom-report' && (
                            <PageSpinner />
                        )}
                        <Suspense fallback={<PageSpinner />}>
                        {mountedPages.has('search') && (
                        <div style={{ display: currentView === 'search' ? 'block' : 'none' }}>
                            <>
                            {activeSearch ? (
                                <SearchResultsPage
                                    data={{ results: activeSearch.results || [], query: activeSearch.query, params: activeSearch.params, id: activeSearch.id }}
                                    products={searchPageDataRef.current.products}
                                    pricingRules={searchPageDataRef.current.pricingRules}
                                    themeColor={userProfile.themeColor}
                                    timeLabel={activeSearch.timeLabel}
                                    onRefine={handleRefineSearch}
                                    searchConfig={searchConfig}
                                    priceChangeHistory={priceChangeHistory}
                                    thresholds={thresholds}
                                    headerStyle={headerStyle}
                                    skuFamilies={searchPageDataRef.current.skuFamilies}
                                    adGroups={searchPageDataRef.current.adGroups}
                                    promotions={searchPageDataRef.current.promotions}
                                    priceHistoryMap={searchPageDataRef.current.priceHistoryMap}
                                    optimalPriceResults={searchPageDataRef.current.optimalPriceResults}
                                    navigateToEntity={navigateToEntity}
                                />
                            ) : (
                                <div className="flex flex-col items-center justify-center h-full text-gray-400">
                                    <Search className="w-12 h-12 mb-4 opacity-50" />
                                    <p className="text-lg font-medium">{t('search_empty_state')}</p>
                                </div>
                            )}
                            </>
                        </div>)}
                        <div style={{ display: currentView === 'overview' ? 'block' : 'none' }}>
                            {products.length === 0 ? (
                                (syncStatus === 'syncing' || (startupSyncMode === 'sync' && syncStatus !== 'error')) ? (
                                    <div className="flex flex-col items-center justify-center min-h-[500px]">
                                        <div className="w-16 h-16 rounded-full flex items-center justify-center mb-6"
                                            style={{ backgroundColor: `${userProfile.themeColor}15` }}>
                                            <Loader2 className="w-8 h-8 animate-spin"
                                                style={{ color: userProfile.themeColor }} />
                                        </div>
                                        <h3 className="text-xl font-bold text-gray-900">
                                            Loading your data...
                                        </h3>
                                        <p className="text-gray-500 mt-2">
                                            Syncing from database, please wait.
                                        </p>
                                        {syncTotal > 0 && (
                                            <div className="w-64 mt-6">
                                                <div className="flex justify-between text-xs text-gray-400 mb-1">
                                                    <span>{syncStep}</span>
                                                    <span>{Math.round((syncProgress / syncTotal) * 100)}%</span>
                                                </div>
                                                <div className="w-full bg-gray-200 rounded-full h-2">
                                                    <div
                                                        className="rounded-full h-2 transition-all duration-300"
                                                        style={{
                                                            width: `${Math.round((syncProgress / syncTotal) * 100)}%`,
                                                            backgroundColor: userProfile.themeColor
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                ) : syncStatus === 'error' ? (
                                    <div className="flex flex-col items-center justify-center min-h-[500px]">
                                        <div className="w-16 h-16 rounded-full bg-red-50 flex items-center justify-center mb-6">
                                            <Database className="w-8 h-8 text-red-400" />
                                        </div>
                                        <h3 className="text-xl font-bold text-gray-900">Could not load data</h3>
                                        <p className="text-gray-500 mt-2 mb-6">Failed to sync from database.</p>
                                        <button
                                            onClick={handleSync}
                                            className="px-6 py-2 rounded-lg text-white font-medium"
                                            style={{ backgroundColor: userProfile.themeColor }}
                                        >
                                            Try Again
                                        </button>
                                    </div>
                                ) : (startupSyncMode === 'local') ? (
                                    <div className="flex flex-col items-center justify-center min-h-[500px] bg-custom-glass rounded-2xl border-2 border-dashed border-custom-glass text-center p-12 h-full">
                                        <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6 shadow-sm"
                                            style={{ backgroundColor: `${userProfile.themeColor}15`, color: userProfile.themeColor }}>
                                            <Database className="w-10 h-10" />
                                        </div>
                                        <h3 className="text-2xl font-bold text-gray-900">{t('welcome_title')}</h3>
                                        <p className="text-gray-500 max-w-lg mt-3 mb-10 text-lg">{t('welcome_desc')}</p>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl relative">
                                            <div className={`rounded-xl p-8 border transition-all flex flex-col items-center relative group ${hasInventory ? 'bg-green-50/50 border-green-200' : 'bg-gray-50/50 border-gray-200 hover:border-indigo-300'}`}>
                                                <div className={`absolute -top-4 px-4 py-1 rounded-full text-sm font-bold shadow-sm ${hasInventory ? 'bg-green-600 text-white' : 'text-white'}`}
                                                    style={!hasInventory ? { backgroundColor: userProfile.themeColor } : {}}>
                                                    {hasInventory ? t('step_completed') : t('step_1')}
                                                </div>
                                                <div className="p-4 bg-white rounded-full shadow-sm mb-4">
                                                    {hasInventory ? <CheckCircle className="w-8 h-8 text-green-600" /> : <Database className="w-8 h-8" style={{ color: userProfile.themeColor }} />}
                                                </div>
                                                <h4 className="font-bold text-gray-900 text-lg">{t('empty_state_erp_title')}</h4>
                                                <p className="text-sm text-gray-500 mt-2 text-center">{t('empty_state_erp_desc')}</p>
                                                <button
                                                    onClick={() => setIsUploadModalOpen(true)}
                                                    className={`mt-6 w-full py-3 bg-white border text-gray-700 font-bold rounded-lg transition-all flex items-center justify-center gap-2 ${hasInventory ? 'border-green-300 text-green-700' : 'border-gray-300'}`}
                                                    style={!hasInventory ? { borderColor: userProfile.themeColor, color: userProfile.themeColor } : {}}
                                                >
                                                    {hasInventory ? t('reupload_inventory') : t('upload_inventory')}
                                                </button>
                                            </div>
                                            <div className={`rounded-xl p-8 border transition-all flex flex-col items-center relative ${!hasInventory ? 'bg-gray-50/50 border-gray-200 opacity-60' : 'bg-custom-glass border-theme-20 shadow-lg scale-105 z-10'}`}>
                                                <div className={`absolute -top-4 px-4 py-1 rounded-full text-sm font-bold shadow-sm ${!hasInventory ? 'bg-gray-400 text-white' : 'text-white'}`}
                                                    style={hasInventory ? { backgroundColor: userProfile.themeColor } : {}}>
                                                    {t('step_2')}
                                                </div>
                                                <div className="p-4 bg-white rounded-full shadow-sm mb-4">
                                                    <FileBarChart className={`w-8 h-8 ${!hasInventory ? 'text-gray-400' : ''}`}
                                                        style={hasInventory ? { color: userProfile.themeColor } : {}} />
                                                </div>
                                                <h4 className="font-bold text-gray-900 text-lg">{t('empty_state_sales_title')}</h4>
                                                <p className="text-sm text-gray-500 mt-2 text-center">{t('empty_state_sales_desc')}</p>
                                                <button
                                                    onClick={() => hasInventory && setIsSalesImportModalOpen(true)}
                                                    disabled={!hasInventory}
                                                    style={hasInventory ? { backgroundColor: userProfile.themeColor } : {}}
                                                    className={`mt-6 w-full py-3 font-bold rounded-lg flex items-center justify-center gap-2 text-white transition-all ${!hasInventory ? 'bg-gray-300' : 'hover:opacity-90 shadow-lg'}`}
                                                >
                                                    <Upload className="w-5 h-5" /> {t('upload_sales')}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="flex flex-col items-center justify-center min-h-[500px]">
                                        <div className="w-16 h-16 rounded-full bg-gray-50 flex items-center justify-center mb-6">
                                            <Database className="w-8 h-8 text-gray-400" />
                                        </div>
                                        <h3 className="text-xl font-bold text-gray-900">No data available</h3>
                                        <p className="text-gray-500 mt-2 mb-6 text-center max-w-sm">
                                            Waiting for admin to upload data. Try syncing again later.
                                        </p>
                                        <button
                                            onClick={handleSync}
                                            className="px-6 py-2 rounded-lg border border-gray-300 text-gray-600 font-medium hover:bg-gray-50"
                                        >
                                            Sync Again
                                        </button>
                                    </div>
                                )
                            ) : (
                                <OverviewPageContainer
                                    products={overviewPageDataRef.current.products}
                                    priceHistoryMap={overviewPageDataRef.current.priceHistoryMap}
                                    refundHistory={overviewPageDataRef.current.refundHistory}
                                    pricingRules={overviewPageDataRef.current.pricingRules}
                                    priceChangeHistory={overviewPageDataRef.current.priceChangeHistory}
                                    promotions={overviewPageDataRef.current.promotions}
                                    themeColor={userProfile.themeColor}
                                    onAnalyze={handleAnalyze}
                                    onDeepDive={(sku) => navigateToEntity({
                                        targetView: 'search',
                                        entityType: 'sku',
                                        entityId: sku,
                                        sourceView: currentView
                                    })}
                                    onSearch={handleSearch}
                                    thresholds={overviewPageDataRef.current.thresholds}
                                    mapJumpState={overviewPageDataRef.current.mapJumpState}
                                />
                            )}
                        </div>
                        {mountedPages.has('products') && (
                        <div style={{ display: currentView === 'products' ? 'block' : 'none' }}>
                            <ProductManagementPage
                                products={productPageDataRef.current.products}
                                pricingRules={productPageDataRef.current.pricingRules}
                                promotions={productPageDataRef.current.promotions}
                                priceHistoryMap={productPageDataRef.current.priceHistoryMap}
                                refundHistory={productPageDataRef.current.refundHistory}
                                deductRefunds={deductRefunds}
                                setDeductRefunds={setDeductRefunds}
                                priceChangeHistory={productPageDataRef.current.priceChangeHistory}
                                inventoryChangeHistory={productPageDataRef.current.inventoryChangeHistory}
                                onOpenMappingModal={() => setIsMappingModalOpen(true)}
                                dateLabels={dynamicDateLabels}
                                onUpdateProduct={(p) => setProducts(prev => (prev || []).map(old => old.id === p.id ? p : old))}
                                onViewElasticity={handleViewElasticityWithResult}
                                themeColor={userProfile.themeColor}
                                onAnalyze={handleAnalyze}
                                onDeepDive={(sku) => navigateToEntity({
                                    targetView: 'search',
                                    entityType: 'sku',
                                    entityId: sku,
                                    sourceView: currentView
                                })}
                                onSearch={handleSearch}
                                thresholds={thresholds}
                                onAnalyzeCarrier={handleAnalyzeCarrier}
                                skuFamilies={productPageDataRef.current.skuFamilies}
                                setSkuFamilies={setSkuFamilies}
                                pendingFamilySuggestions={productPageDataRef.current.pendingFamilySuggestions}
                                setPendingFamilySuggestions={setPendingFamilySuggestions}
                                headerStyle={headerStyle}
                                cohortSnapshot={productPageDataRef.current.cohortSnapshot}
                                optimalPriceResults={productPageDataRef.current.optimalPriceResults}
                                benchmarkUpdateNotices={productPageDataRef.current.benchmarkUpdateNotices}
                                onRecalculateBenchmarks={handleRecalculateBenchmarks}
                                benchmarkRecalcState={productPageDataRef.current.benchmarkRecalcState}
                                onCancelBenchmarkRecalculation={handleCancelBenchmarkRecalculation}
                                onDismissBenchmarkRecalcState={handleDismissBenchmarkRecalcState}
                                onStampLandedAt={handleStampLandedAt}
                                onEditContainerShipments={(payload: { containerId: string; status?: string; eta?: string; items: { sku: string; quantity: number }[] }) => {
                                    const targetId = String(payload?.containerId || '').trim();
                                    if (!targetId) return;
                                    const normalizeStatus = (status?: string): string => {
                                        const raw = String(status || '').trim();
                                        if (!raw) return 'Pending';
                                        const first = raw.includes('/') ? raw.split('/')[0].trim() : raw;
                                        const cleaned = first.replace(/[\u4E00-\u9FFF]/g, '').trim();
                                        return cleaned || 'Pending';
                                    };
                                    const isArrivedLike = (status?: string) => {
                                        const cleaned = normalizeStatus(status).toLowerCase();
                                        return cleaned.includes('arrived') || cleaned.includes('delivered') || cleaned.includes('cleared') || cleaned.includes('received') || cleaned.includes('landed');
                                    };
                                    const qtyBySku = new Map<string, number>();
                                    (payload?.items || []).forEach((item) => {
                                        const sku = String(item?.sku || '').trim();
                                        const qty = Math.max(0, Math.round(Number(item?.quantity) || 0));
                                        if (!sku || qty <= 0) return;
                                        qtyBySku.set(sku, qty);
                                    });
                                    setProducts(prev => {
                                        if (!Array.isArray(prev) || prev.length === 0) return prev;
                                        let fallbackStatus = normalizeStatus(payload?.status);
                                        let fallbackEta = String(payload?.eta || '').trim() || undefined;
                                        if (!payload?.status || !payload?.eta) {
                                            for (let i = 0; i < prev.length; i++) {
                                                const p = prev[i];
                                                const shipments = Array.isArray(p.shipments) ? p.shipments : [];
                                                for (let j = 0; j < shipments.length; j++) {
                                                    const s = shipments[j];
                                                    if (String(s?.containerId || '').trim() !== targetId) continue;
                                                    if (!payload?.status && s?.status) fallbackStatus = normalizeStatus(s.status);
                                                    if (!payload?.eta && s?.eta) fallbackEta = String(s.eta).trim();
                                                    break;
                                                }
                                                if ((!payload?.status && fallbackStatus) && (!payload?.eta ? !!fallbackEta : true)) break;
                                            }
                                        }

                                        return prev.map((p) => {
                                            const currentShipments = Array.isArray(p.shipments) ? p.shipments : [];
                                            const kept = currentShipments.filter((s: any) => String(s?.containerId || '').trim() !== targetId);
                                            const nextShipments = [...kept];
                                            const nextQty = qtyBySku.get(String(p.sku || '').trim());
                                            if (typeof nextQty === 'number' && nextQty > 0) {
                                                nextShipments.push({
                                                    containerId: targetId,
                                                    quantity: nextQty,
                                                    status: fallbackStatus || 'Pending',
                                                    eta: fallbackEta
                                                });
                                            }
                                            if (nextShipments.length === currentShipments.length &&
                                                nextShipments.every((s, idx) => s === currentShipments[idx])) {
                                                return p;
                                            }
                                            let incomingStock = 0;
                                            for (let i = 0; i < nextShipments.length; i++) {
                                                const s = nextShipments[i];
                                                if (!isArrivedLike(s?.status)) incomingStock += (Number(s?.quantity) || 0);
                                            }
                                            return { ...p, shipments: nextShipments, incomingStock };
                                        });
                                    });
                                }}
                                onConfirmContainersArrived={(payload: { containerId: string; confirmedQty?: number; confirmedSkuQtys?: Record<string, number>; mode?: 'INFERRED' | 'MANUAL' }[]) => {
                                    const targetRecords = new Map<string, { confirmedQty?: number; confirmedSkuQtys?: Record<string, number>; mode?: 'INFERRED' | 'MANUAL' }>();
                                    (payload || []).forEach((item) => {
                                        const id = String(item?.containerId || '').trim();
                                        if (!id) return;
                                        targetRecords.set(id, {
                                            confirmedQty: item?.confirmedQty,
                                            confirmedSkuQtys: item?.confirmedSkuQtys,
                                            mode: item?.mode || 'MANUAL'
                                        });
                                    });
                                    if (targetRecords.size === 0) return;
                                    const isArrivedLike = (status?: string) => {
                                        const raw = String(status || '').trim();
                                        if (!raw) return false;
                                        const first = raw.includes('/') ? raw.split('/')[0].trim() : raw;
                                        const cleaned = first.replace(/[\u4E00-\u9FFF]/g, '').trim().toLowerCase();
                                        return cleaned.includes('arrived') || cleaned.includes('delivered') || cleaned.includes('cleared') || cleaned.includes('received') || cleaned.includes('landed');
                                    };
                                    const nowIso = new Date().toISOString();
                                    setProducts(prev => {
                                        if (!Array.isArray(prev) || prev.length === 0) return prev;
                                        return prev.map(p => {
                                            const currentShipments = Array.isArray(p.shipments) ? p.shipments : [];
                                            if (currentShipments.length === 0) return p;
                                            let touched = false;
                                            const nextShipments = new Array(currentShipments.length);
                                            for (let i = 0; i < currentShipments.length; i++) {
                                                const s = currentShipments[i];
                                                const id = String(s?.containerId || '').trim();
                                                const rec = id ? targetRecords.get(id) : undefined;
                                                if (!rec) {
                                                    nextShipments[i] = s;
                                                    continue;
                                                }
                                                touched = true;
                                                const skuKey = String(p.sku || '').trim();
                                                const skuOverrideRaw = rec.confirmedSkuQtys ? rec.confirmedSkuQtys[skuKey] : undefined;
                                                const skuOverride = Number.isFinite(Number(skuOverrideRaw)) ? Math.round(Number(skuOverrideRaw)) : undefined;
                                                nextShipments[i] = {
                                                    ...s,
                                                    status: 'Arrived (Confirmed)',
                                                    arrivalConfirmedQty: typeof skuOverride === 'number'
                                                        ? Math.max(0, skuOverride)
                                                        : rec.confirmedQty,
                                                    arrivalConfirmedAt: nowIso,
                                                    arrivalConfirmationMode: rec.mode || 'MANUAL',
                                                    arrivalConfirmedSkuQtys: rec.confirmedSkuQtys
                                                };
                                            }
                                            if (!touched) return p;
                                            let incomingStock = 0;
                                            for (let i = 0; i < nextShipments.length; i++) {
                                                const s = nextShipments[i];
                                                if (!isArrivedLike(s?.status)) incomingStock += (Number(s?.quantity) || 0);
                                            }
                                            return { ...p, shipments: nextShipments, incomingStock };
                                        });
                                    });
                                }}
                            />
                        </div>)}
                        {mountedPages.has('platforms') && (
                        <div style={{ display: currentView === 'platforms' ? 'block' : 'none' }}>
                            <PlatformManagementPage
                                products={platformsPageDataRef.current.products}
                                priceHistoryMap={platformsPageDataRef.current.priceHistoryMap}
                                refundHistory={platformsPageDataRef.current.refundHistory}
                                deductRefunds={deductRefunds}
                                setDeductRefunds={setDeductRefunds}
                                pricingRules={platformsPageDataRef.current.pricingRules}
                                themeColor={userProfile.themeColor}
                                adGroups={platformsPageDataRef.current.adGroups}
                                skuFamilies={platformsPageDataRef.current.skuFamilies}
                                onSyncFromFamilies={onSyncFromFamilies}
                                onAddAdGroup={onAddAdGroup}
                                onEditAdGroup={onEditAdGroup}
                                onRemoveAdGroup={onRemoveAdGroup}
                                onSaveAdGroups={handleAdGroupSave}
                                lastRecalculationSummary={platformsPageDataRef.current.lastRecalculationSummary}
                                headerStyle={headerStyle}
                            />
                        </div>)}
                        {mountedPages.has('strategy') && (
                        <div style={{ display: currentView === 'strategy' ? 'block' : 'none' }}>
                            <StrategyPage
                                products={strategyPageDataRef.current.products}
                                pricingRules={strategyPageDataRef.current.pricingRules}
                                currentConfig={strategyRules}
                                onSaveConfig={(newConfig: StrategyConfig) => { setStrategyRules(newConfig); }}
                                themeColor={userProfile.themeColor}
                                priceHistoryMap={strategyPageDataRef.current.priceHistoryMap}
                                refundHistory={strategyPageDataRef.current.refundHistory}
                                deductRefunds={deductRefunds}
                                setDeductRefunds={setDeductRefunds}
                                promotions={strategyPageDataRef.current.promotions}
                                priceChangeHistory={strategyPageDataRef.current.priceChangeHistory}
                                costChangeHistory={strategyPageDataRef.current.costChangeHistory}
                                inventoryChangeHistory={strategyPageDataRef.current.inventoryChangeHistory}
                                onUpdatePriceChangeRecord={handleUpdatePriceChangeRecord}
                                onUpdateCostChangeRecord={handleUpdateCostChangeRecord}
                                onUpdateInventoryChangeRecord={handleUpdateInventoryChangeRecord}
                                onManualPriceChange={handleManualPriceChange}
                                onManualCostChange={handleManualCostChange}
                                velocityLookback={velocityLookback}
                                thresholds={thresholds}
                                skuFamilies={strategyPageDataRef.current.skuFamilies}
                                optimalPriceResults={strategyPageDataRef.current.optimalPriceResults}
                            />
                        </div>)}
                        {mountedPages.has('costs') && (
                        <div style={{ display: currentView === 'costs' ? 'block' : 'none' }}>
                            <CostManagementPage products={products} themeColor={userProfile.themeColor} headerStyle={headerStyle} />
                        </div>)}
                        {mountedPages.has('promotions') && (
                        <div style={{ display: currentView === 'promotions' ? 'block' : 'none' }}>
                            <PromotionPage
                                products={promotionsPageDataRef.current.products}
                                pricingRules={promotionsPageDataRef.current.pricingRules}
                                logisticsRules={promotionsPageDataRef.current.logisticsRules}
                                promotions={promotionsPageDataRef.current.promotions}
                                priceHistoryMap={promotionsPageDataRef.current.priceHistoryMap}
                                onAddPromotion={(p) => startTransition(() => setPromotions(prev => [...(prev || []), p]))}
                                onUpdatePromotion={(p) => startTransition(() => setPromotions(prev => (prev || []).map(o => o.id === p.id ? p : o)))}
                                onDeletePromotion={(id) => startTransition(() => setPromotions(prev => (prev || []).filter(p => p.id !== id)))}
                                themeColor={userProfile.themeColor}
                                headerStyle={headerStyle}
                                navigationIntent={navigationIntent}
                                onConsumeNavigationIntent={handleConsumeNavigationIntent}
                            />
                        </div>)}
                        {mountedPages.has('ad-campaigns') && (
                        <div style={{ display: currentView === 'ad-campaigns' ? 'block' : 'none' }}>
                            <AdCampaignPageContainer
                                products={adCampaignPageDataRef.current.products}
                                salesHistory={adCampaignPageDataRef.current.salesHistory}
                                learnedAliases={learnedAliases || {}}
                                adSnapshots={adCampaignPageDataRef.current.adSnapshots}
                                adRosterChanges={adCampaignPageDataRef.current.adRosterChanges}
                                adBudgets={adCampaignPageDataRef.current.adBudgets}
                                onImport={handleAdCampaignImport}
                                onRosterChange={handleAdRosterChange}
                            />
                        </div>)}
                        {mountedPages.has('tools') && (
                        <div style={{ display: currentView === 'tools' ? 'block' : 'none' }}>
                            <ToolboxPage
                                promotions={toolsPageDataRef.current.promotions}
                                freightRates={toolsPageDataRef.current.freightRates}
                                learnedAliases={learnedAliases || {}}
                                pricingRules={toolsPageDataRef.current.pricingRules}
                                inventoryTemplates={toolsPageDataRef.current.inventoryTemplates}
                                onSaveTemplates={setInventoryTemplates}
                                onSaveLearnedAliases={(aliases) => setLearnedAliases(prev => ({ ...prev, ...aliases }))}
                                products={toolsPageDataRef.current.products}
                                themeColor={userProfile.themeColor}
                                headerStyle={headerStyle}
                                salesHistory={toolsPageDataRef.current.salesHistory}
                                refundHistory={toolsPageDataRef.current.refundHistory}
                                priceCheckTemplates={toolsPageDataRef.current.priceCheckTemplates}
                                onSavePriceCheckTemplates={handleSavePriceCheckTemplates}
                                onDescriptionImport={handleDescriptionImport}
                            />
                        </div>)}
                        {mountedPages.has('definitions') && (
                        <div style={{ display: currentView === 'definitions' ? 'block' : 'none' }}>
                            <DefinitionsPage />
                        </div>)}
                        {mountedPages.has('custom-report') && (
                        <div style={{ display: currentView === 'custom-report' ? 'block' : 'none' }}>
                            <CustomReportPage
                                products={customReportPageDataRef.current.products}
                                priceHistory={customReportPageDataRef.current.priceHistory}
                                refundHistory={customReportPageDataRef.current.refundHistory}
                                pricingRules={customReportPageDataRef.current.pricingRules}
                                customReportPresets={customReportPageDataRef.current.customReportPresets}
                                setCustomReportPresets={setCustomReportPresets}
                                isAdminMode={isAdminMode}
                            />
                        </div>)}
                        {mountedPages.has('settings') && (
                        <div style={{ display: currentView === 'settings' ? 'block' : 'none' }}>
                            <SettingsPage
                                currentRules={settingsPageDataRef.current.currentRules}
                                onSave={(newRules, newVelocity, newSearchConfig) => {
                                    setPricingRules(newRules);
                                    setVelocityLookback(newVelocity);
                                    if (newSearchConfig) setSearchConfig(newSearchConfig);
                                    localStorage.setItem('sello_velocity_setting', newVelocity);
                                    handleRecalculateVelocity(newVelocity, salesHistory);
                                }}
                                logisticsRules={settingsPageDataRef.current.logisticsRules}
                                onSaveLogistics={(newLogistics) => { setLogisticsRules(newLogistics); }}
                                products={settingsPageDataRef.current.products}
                                freightRates={settingsPageDataRef.current.freightRates}
                                onFreightRatesUpload={handleFreightRatesUpload}
                                onOpenFreightUpload={() => setIsFreightModalOpen(true)}
                                themeColor={userProfile.themeColor}
                                searchConfig={settingsPageDataRef.current.searchConfig}
                                velocityLookback={settingsPageDataRef.current.velocityLookback}
                                extraData={settingsPageDataRef.current.extraData}
                                onRefreshThresholds={handleRefreshThresholds}
                                brandMap={settingsPageDataRef.current.brandMap}
                                categoryMap={settingsPageDataRef.current.categoryMap}
                                onSaveBrandMap={handleSaveBrandMap}
                                onSaveCategoryMap={handleSaveCategoryMap}
                                headerStyle={headerStyle}
                            />
                        </div>)}
                        </Suspense>
                            </>
                        )}
                    </div>
                </main>
                <Suspense fallback={null}>
                {isUploadModalOpen && (
                    <BatchUploadModal
                        products={products}
                        onClose={() => setIsUploadModalOpen(false)}
                        onConfirm={handleInventoryImport}
                    />
                )
                }
                {
                    isSalesImportModalOpen && (
                        <SalesImportModal
                            products={products}
                            pricingRules={pricingRules}
                            salesHistory={salesHistory}
                            learnedAliases={learnedAliases}
                            onClose={() => setIsSalesImportModalOpen(false)}
                            onResetData={handleResetSalesData}
                            onConfirm={handleSalesImportConfirm}
                        />
                    )
                }
                {
                    isSkuDetailModalOpen && (
                        <SkuDetailUploadModal
                            products={products}
                            onClose={() => setIsSkuDetailModalOpen(false)}
                            onConfirm={handleSkuDetailImport}
                        />
                    )
                }
                {
                    isMappingModalOpen && (
                        <MappingUploadModal
                            products={products}
                            platforms={Object.keys(pricingRules)}
                            learnedAliases={learnedAliases}
                            onClose={() => setIsMappingModalOpen(false)}
                            onConfirm={handleMappingImport}
                        />
                    )
                }
                {
                    isReturnsModalOpen && (
                        <ReturnsUploadModal
                            onClose={() => setIsReturnsModalOpen(false)}
                            onConfirm={handleReturnsImport}
                            onReset={handleResetRefunds}
                            existingOrders={existingOrders}
                        />
                    )
                }
                {
                    isCAUploadModalOpen && (
                        <CAUploadModal
                            products={products}
                            onClose={() => setIsCAUploadModalOpen(false)}
                            onConfirm={handleCAImport}
                        />
                    )
                }
                {
                    isFreightModalOpen && (
                        <FreightUploadModal
                            products={products || []}
                            onClose={() => setIsFreightModalOpen(false)}
                            onConfirm={handleFreightRatesUpload}
                        />
                    )}
                    {isShipmentModalOpen && (
                        <ShipmentUploadModal
                            products={products}
                            onClose={() => setIsShipmentModalOpen(false)}
                            onConfirm={handleShipmentImport}
                        />
                    )
                }
                {
                    selectedElasticityProduct && (
                        <PriceElasticityModal
                            product={selectedElasticityProduct}
                            result={elasticityResult ?? undefined}
                            onClose={() => {
                                setSelectedElasticityProduct(null);
                                setElasticityResult(null);
                            }}
                        />
                    )
                }
                {
                    selectedAnalysisProduct && (
                        <AnalysisModal
                            product={selectedAnalysisProduct}
                            analysis={analysisResult}
                            isLoading={isAnalysisLoading}
                            onClose={() => { setSelectedAnalysisProduct(null); setAnalysisResult(null); }}
                            onApplyPrice={handleApplyPrice}
                            themeColor={userProfile.themeColor}
                        />
                    )
                }
                </Suspense>

                <button
                    onClick={() => {
                        if (mainContentRef.current) {
                            mainContentRef.current.scrollTo({ top: 0, behavior: 'smooth' });
                        }
                    }}
                    className={`fixed bottom-8 right-8 p-2.5 rounded-full bg-custom-glass border border-custom-glass shadow-lg hover:shadow-xl transition-all duration-300 z-[60] flex items-center justify-center ${showBackToTop ? 'opacity-70 hover:opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}`}
                    style={{ borderColor: `${userProfile.themeColor}40`, color: userProfile.themeColor }}
                    aria-label="Back to top"
                >
                    <ArrowUp className="w-5 h-5" />
                </button>
            </div>

            {/* Admin Password Modal */}
            {
                showAdminModal && (
                    <AdminModal
                        onClose={() => setShowAdminModal(false)}
                        onSuccess={() => setShowAdminModal(false)}
                        handleAdminToggle={handleAdminToggle}
                    />
                )
            }

            {/* Exit Confirmation Dialog */}
            {
                showExitConfirm && (
                    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
                        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200">
                            <div className="p-6">
                                <h3 className="text-base font-bold text-gray-900 mb-2">Unsaved Changes</h3>
                                <p className="text-sm text-gray-600">You have changes that haven&apos;t been pushed to the database. What would you like to do?</p>
                            </div>
                            <div className="px-6 pb-6 flex flex-col gap-2">
                                <button
                                    onClick={async () => { setShowExitConfirm(false); await handleAdminPush(); handleAdminExit(true); }}
                                    className="w-full px-4 py-2.5 bg-theme text-white rounded-xl text-sm font-bold hover:opacity-90 transition-all"
                                >
                                    Push Now
                                </button>
                                <button
                                    onClick={() => { setShowExitConfirm(false); handleAdminExit(true); }}
                                    className="w-full px-4 py-2.5 bg-gray-100 text-gray-700 rounded-xl text-sm font-bold hover:bg-gray-200 transition-all"
                                >
                                    Exit Anyway
                                </button>
                                <button
                                    onClick={() => setShowExitConfirm(false)}
                                    className="w-full px-4 py-2 text-gray-400 text-sm font-medium hover:text-gray-600 transition-all"
                                >
                                    Cancel
                                </button>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* Save Toast */}
            {
                showSaveToast && (
                    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] animate-in slide-in-from-bottom-4 duration-300">
                        <div className="flex items-center gap-2.5 px-5 py-3 bg-green-600 text-white rounded-xl shadow-xl font-bold text-sm">
                            <CheckCircle className="w-4 h-4" />
                            Pushed to database
                        </div>
                    </div>
                )
            }
            {
                navigationNotice && (
                    <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[200] animate-in slide-in-from-bottom-4 duration-300">
                        <div className="flex items-center gap-2.5 px-5 py-3 bg-amber-600 text-white rounded-xl shadow-xl font-bold text-sm">
                            <Bell className="w-4 h-4" />
                            {navigationNotice}
                        </div>
                    </div>
                )
            }
        </>
    );
};

export default App;

